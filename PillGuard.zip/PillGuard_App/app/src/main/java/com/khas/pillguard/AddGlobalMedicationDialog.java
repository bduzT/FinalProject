package com.khas.pillguard.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.khas.pillguard.R;
import com.khas.pillguard.models.Medication;

public class AddGlobalMedicationDialog extends Dialog {

    private EditText etMedicationName, etDescription, etDosage;
    private Button btnSave, btnCancel;
    private OnMedicationSavedListener listener;

    public interface OnMedicationSavedListener {
        void onMedicationSaved(Medication medication);
    }

    public AddGlobalMedicationDialog(@NonNull Context context, OnMedicationSavedListener listener) {
        super(context);
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_add_medication);

        etMedicationName = findViewById(R.id.etMedicationName);
        etDescription = findViewById(R.id.etDescription);
        etDosage = findViewById(R.id.etDosage);

        btnSave = findViewById(R.id.btnSaveMedication);
        btnCancel = findViewById(R.id.btnCancelMedication);

        btnSave.setOnClickListener(v -> {
            String name = etMedicationName.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String dosage = etDosage.getText().toString().trim();

            if (name.isEmpty() || dosage.isEmpty()) {
                Toast.makeText(getContext(), "Please fill in required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Medication med = new Medication();
            med.setMedicationName(name);
            med.setDescription(description);
            med.setDosage(dosage);
            med.setActive(true);
            med.setQrCode("QR_" + System.currentTimeMillis());

            if (listener != null) {
                listener.onMedicationSaved(med);
            }

            dismiss();
        });

        btnCancel.setOnClickListener(v -> dismiss());
    }
}
