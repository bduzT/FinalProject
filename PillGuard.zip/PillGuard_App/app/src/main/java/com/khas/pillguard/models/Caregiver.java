package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;

public class Caregiver {
    @SerializedName("id")
    private int caregiverId;

    @SerializedName("firstName")
    private String firstName;

    @SerializedName("lastName")
    private String lastName;

    @SerializedName("contactInfo")
    private String contactInfo;

    @SerializedName("dateOfBirth")
    private String dateOfBirth;

    @SerializedName("profilePicturePath")
    private String photo;

    @SerializedName("adminId")
    private int adminId;

    @SerializedName("username")
    private String username;

    @SerializedName("password")
    private String password;

    // ---- Constructors ----

    public Caregiver() {}

    public Caregiver(int caregiverId, String firstName, String lastName, String contactInfo, String dateOfBirth, String photo) {
        this.caregiverId = caregiverId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactInfo = contactInfo;
        this.dateOfBirth = dateOfBirth;
        this.photo = photo;
    }

    public Caregiver(int caregiverId, String firstName, String lastName, String contactInfo, String dateOfBirth, String photo, int adminId) {
        this(caregiverId, firstName, lastName, contactInfo, dateOfBirth, photo);
        this.adminId = adminId;
    }

    public Caregiver(int caregiverId, String firstName, String lastName, String contactInfo, String dateOfBirth, String photo, int adminId, String username, String password) {
        this(caregiverId, firstName, lastName, contactInfo, dateOfBirth, photo, adminId);
        this.username = username;
        this.password = password;
    }

    // ---- Getters & Setters ----

    public int getCaregiverId() {
        return caregiverId;
    }

    public void setCaregiverId(int caregiverId) {
        this.caregiverId = caregiverId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // ---- toString() override for Spinner ----
    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}
