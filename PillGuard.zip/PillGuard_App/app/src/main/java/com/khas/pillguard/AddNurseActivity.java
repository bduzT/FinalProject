package com.khas.pillguard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.CaregiverResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddNurseActivity extends AppCompatActivity {
    private EditText etNurseName, etNurseSurname, etNurseDOB, etNurseContact, etNurseUsername, etNursePassword;
    private Button btnUploadPhoto, btnAddNurse;
    private ImageView ivPhotoPreview;
    private ApiService apiService;
    private Uri selectedImageUri;

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int REQUEST_READ_EXTERNAL_STORAGE = 200;
    private static final String TAG = "AddNurseActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_nurse);

        etNurseName = findViewById(R.id.etNurseName);
        etNurseSurname = findViewById(R.id.etNurseSurname);
        etNurseDOB = findViewById(R.id.etNurseDOB);
        etNurseContact = findViewById(R.id.etNurseContact);
        etNurseUsername = findViewById(R.id.etNurseUsername);
        etNursePassword = findViewById(R.id.etNursePassword);

        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
        btnAddNurse = findViewById(R.id.btnAddNurse);
        ivPhotoPreview = findViewById(R.id.ivPhotoPreview);

        apiService = ApiClient.instance;

        // Tüm alanlara 10 karakter sınırı
        etNurseName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), lettersOnlyFilter});
        etNurseSurname.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), lettersOnlyFilter});
        etNurseDOB.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        etNurseContact.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        etNurseUsername.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), alphanumericFilter});
        etNursePassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), alphanumericFilter});

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_READ_EXTERNAL_STORAGE);
        }

        btnUploadPhoto.setOnClickListener(v -> pickImage());
        btnAddNurse.setOnClickListener(v -> addNurse());
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void addNurse() {
        String firstName = etNurseName.getText().toString().trim();
        String lastName = etNurseSurname.getText().toString().trim();
        String contactInfo = etNurseContact.getText().toString().trim();
        String dateOfBirth = etNurseDOB.getText().toString().trim();
        String username = etNurseUsername.getText().toString().trim();
        String password = etNursePassword.getText().toString().trim();
        String adminIdStr = "1";

        if (firstName.isEmpty() || lastName.isEmpty() || dateOfBirth.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        RequestBody firstNameBody = RequestBody.create(MediaType.parse("text/plain"), firstName);
        RequestBody lastNameBody = RequestBody.create(MediaType.parse("text/plain"), lastName);
        RequestBody contactInfoBody = RequestBody.create(MediaType.parse("text/plain"), contactInfo);
        RequestBody dateOfBirthBody = RequestBody.create(MediaType.parse("text/plain"), dateOfBirth);
        RequestBody usernameBody = RequestBody.create(MediaType.parse("text/plain"), username);
        RequestBody passwordBody = RequestBody.create(MediaType.parse("text/plain"), password);
        RequestBody adminIdBody = RequestBody.create(MediaType.parse("text/plain"), adminIdStr);

        MultipartBody.Part photoPart = null;
        if (selectedImageUri != null) {
            try {
                File photoFile = getFileFromUri(selectedImageUri);
                RequestBody requestFile = RequestBody.create(MediaType.parse(getContentResolver().getType(selectedImageUri)), photoFile);
                photoPart = MultipartBody.Part.createFormData("photo", photoFile.getName(), requestFile);
            } catch (IOException e) {
                Log.e(TAG, "Error processing photo", e);
                Toast.makeText(this, "Error processing photo", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        apiService.addCaregiver(firstNameBody, lastNameBody, contactInfoBody, dateOfBirthBody, photoPart, adminIdBody, usernameBody, passwordBody)
                .enqueue(new Callback<CaregiverResponse>() {
                    @Override
                    public void onResponse(Call<CaregiverResponse> call, Response<CaregiverResponse> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(AddNurseActivity.this, "Nurse added", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(AddNurseActivity.this, "Failed: " + response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<CaregiverResponse> call, Throwable t) {
                        Toast.makeText(AddNurseActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private File getFileFromUri(Uri uri) throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File tempFile = File.createTempFile("JPEG_" + timeStamp, ".jpg", getExternalFilesDir(Environment.DIRECTORY_PICTURES));

        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             FileOutputStream outputStream = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, read);
            }
        }
        return tempFile;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                ivPhotoPreview.setImageBitmap(bitmap);
            } catch (IOException e) {
                Toast.makeText(this, "Image load failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Sadece harf ve boşluk
    private final InputFilter lettersOnlyFilter = (source, start, end, dest, dstart, dend) -> {
        if (!Pattern.compile("^[a-zA-ZğüşıöçĞÜŞİÖÇ\\s]+$").matcher(source).matches()) {
            return "";
        }
        return null;
    };

    // Sadece harf ve rakam
    private final InputFilter alphanumericFilter = (source, start, end, dest, dstart, dend) -> {
        if (!Pattern.compile("^[a-zA-Z0-9]+$").matcher(source).matches()) {
            return "";
        }
        return null;
    };
}
