package com.khas.pillguard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.adapters.MedicationAdapter;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private Button btnViewSchedule;
    private Button btnUnlockBox;
    private Button btnLogoutPatient;
    private RecyclerView rvUpcomingMeds;
    private List<Medication> medicationList;
    private MedicationAdapter adapter;
    private ApiService apiService;
    private int patientId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        btnViewSchedule = findViewById(R.id.btnViewSchedule);
        btnUnlockBox = findViewById(R.id.btnUnlockBox);
        btnLogoutPatient = findViewById(R.id.btnLogout);
        rvUpcomingMeds = findViewById(R.id.rvUpcomingMeds);

        patientId = getIntent().getIntExtra("patientId", -1);
        if (patientId == -1) {
            Toast.makeText(this, "Hasta ID alınamadı", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        medicationList = new ArrayList<>();
        adapter = new MedicationAdapter(this, medicationList, true); // readonly true
        rvUpcomingMeds.setLayoutManager(new LinearLayoutManager(this));
        rvUpcomingMeds.setAdapter(adapter);

        apiService = ApiClient.instance;

        getMedicationsForPatient();

        btnViewSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, PillSchedulePatientActivity.class);
            intent.putExtra("patientId", patientId);
            startActivity(intent);
        });

        btnUnlockBox.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, UnlockBoxActivity.class);
            intent.putExtra("patientId", patientId);
            startActivity(intent);
        });

        btnLogoutPatient.setOnClickListener(v -> logout());
    }

    private void logout() {
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(DashboardActivity.this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void getMedicationsForPatient() {
        Call<List<Medication>> call = apiService.getMedicationsByPatient(patientId);
        call.enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    medicationList.clear();
                    medicationList.addAll(response.body());
                    adapter.notifyDataSetChanged();

                    if (medicationList.isEmpty()) {
                        Toast.makeText(DashboardActivity.this, "No medications found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(DashboardActivity.this, "Failed to load medications", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Toast.makeText(DashboardActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
