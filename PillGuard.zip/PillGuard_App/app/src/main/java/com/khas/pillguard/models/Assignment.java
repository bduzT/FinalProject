package com.khas.pillguard.models;

public class Assignment {
    private int assignmentId;
    private int patientId;
    private String patientName;
    private int caregiverId;
    private String caregiverName;

    public Assignment(int assignmentId, int patientId, String patientName, int caregiverId, String caregiverName) {
        this.assignmentId = assignmentId;
        this.patientId = patientId;
        this.patientName = patientName;
        this.caregiverId = caregiverId;
        this.caregiverName = caregiverName;
    }

    public int getAssignmentId() { return assignmentId; }
    public int getPatientId() { return patientId; }
    public String getPatientName() { return patientName; }
    public int getCaregiverId() { return caregiverId; }
    public String getCaregiverName() { return caregiverName; }
}
