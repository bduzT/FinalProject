package com.khas.pillguard;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.adapters.MedicationAdapter;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PatientScheduleActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MedicationAdapter adapter;
    private List<Medication> medicationList = new ArrayList<>();
    private ApiService apiService;
    private Context context;
    private static final String PREFS_NAME = "PillGuardPrefs";
    private static final String USER_ID_KEY = "userId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_schedule);

        context = this;
        recyclerView = findViewById(R.id.rvPatientMeds);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));

        adapter = new MedicationAdapter(context, medicationList);
        adapter.setReadonly(true);

        recyclerView.setAdapter(adapter);

        apiService = ApiClient.instance;

        int patientId = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(USER_ID_KEY, -1);
        if (patientId != -1) {
            fetchMedications(patientId);
        } else {
            Toast.makeText(context, "Patient ID not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void fetchMedications(int patientId) {
        apiService.getMedicationsByPatient(patientId).enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    medicationList.clear();
                    medicationList.addAll(response.body());
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(context, "Failed to fetch medications", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
