package com.khas.pillguard.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefUtils {

    private static final String PREFS_NAME = "PillGuardPrefs";
    private static final String USER_ID_KEY = "userId";
    private static final String USER_TYPE_KEY = "userType";

    public static int getUserId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(USER_ID_KEY, -1);
    }

    public static String getUserType(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(USER_TYPE_KEY, "");
    }

    public static void clearSession(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(USER_ID_KEY);
        editor.remove(USER_TYPE_KEY);
        editor.apply();
    }
}
