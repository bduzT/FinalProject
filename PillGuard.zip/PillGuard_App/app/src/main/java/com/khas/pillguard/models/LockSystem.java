package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;

public class LockSystem {

    // Assuming LockID is auto-generated on the server
    // @SerializedName("lock_id")
    // private int lockId;

    // PatientID will likely be set on the server side after patient creation
    // @SerializedName("patient_id")
    // private int patientId;

    // Assuming LockStatus, OpenTime, CloseTime, Duration are logged by the physical lock system
    // and not set during patient creation.
    // @SerializedName("lock_status")
    // private String lockStatus; // e.g., 'Locked', 'Unlocked'
    // @SerializedName("open_time")
    // private String openTime; // e.g., "yyyy-MM-dd HH:mm:ss"
    // @SerializedName("close_time")
    // private String closeTime; // e.g., "yyyy-MM-dd HH:mm:ss"
    // @SerializedName("duration")
    // private int duration; // e.g., duration in seconds

    @SerializedName("time_window_start")
    private String timeWindowStart; // e.g., "HH:mm"

    @SerializedName("time_window_end")
    private String timeWindowEnd; // e.g., "HH:mm"

    @SerializedName("allow_access")
    private boolean allowAccess; // e.g., true or false

    public LockSystem() {
        // Default constructor
    }

    // Add getters and setters for the fields that are set from the UI

    public String getTimeWindowStart() {
        return timeWindowStart;
    }

    public void setTimeWindowStart(String timeWindowStart) {
        this.timeWindowStart = timeWindowStart;
    }

    public String getTimeWindowEnd() {
        return timeWindowEnd;
    }

    public void setTimeWindowEnd(String timeWindowEnd) {
        this.timeWindowEnd = timeWindowEnd;
    }

    public boolean isAllowAccess() {
        return allowAccess;
    }

    public void setAllowAccess(boolean allowAccess) {
        this.allowAccess = allowAccess;
    }

    // You might need setters for other fields if they are collected elsewhere
    // public void setLockStatus(String lockStatus) { this.lockStatus = lockStatus; }
    // public void setOpenTime(String openTime) { this.openTime = openTime; }
    // public void setCloseTime(String closeTime) { this.closeTime = closeTime; }
    // public void setDuration(int duration) { this.duration = duration; }
}
