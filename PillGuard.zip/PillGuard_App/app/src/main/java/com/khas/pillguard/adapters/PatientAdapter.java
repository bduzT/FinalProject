package com.khas.pillguard.adapters;

import android.content.Context; // Import Context
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.view.ViewGroup;
import android.widget.TextView; // Import TextView
import androidx.annotation.NonNull; // Import NonNull
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.R; // Make sure this points to your R file
import com.khas.pillguard.models.Patient; // Import the Patient model

import java.util.List; // Import List

public class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.PatientViewHolder> {

    private Context context;
    private List<Patient> patientList;
    private String userRole; // Role eklendi

    public PatientAdapter(Context context, List<Patient> patientList, String userRole) {
        this.context = context;
        this.patientList = patientList;
        this.userRole = userRole;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_patient, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        Patient patient = patientList.get(position);

        holder.tvPatientName.setText(patient.getFirstName() + " " + patient.getLastName());
        holder.tvPatientID.setText("ID: " + patient.getId());
        holder.tvPatientDOB.setText("DOB: " + patient.getDateOfBirth());
        holder.tvPatientGender.setText("Gender: " + patient.getGender());

        // Admin için edit butonunu gizle
        if ("admin".equalsIgnoreCase(userRole)) {
            holder.btnEditPatient.setVisibility(View.GONE);
        } else {
            holder.btnEditPatient.setVisibility(View.VISIBLE);
        }

        // Delete butonu her zaman aktif
        holder.btnDeletePatient.setOnClickListener(v -> {
            // Delete işlemi burada yapılır (callback veya interface ile handle edilir)
        });

        // Edit butonu (sadece hemşirede görünecek)
        holder.btnEditPatient.setOnClickListener(v -> {
            // Edit işlemi burada yapılır
        });
    }

    @Override
    public int getItemCount() {
        return patientList.size();
    }

    public static class PatientViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatientName, tvPatientID, tvPatientDOB, tvPatientGender;
        Button btnEditPatient, btnDeletePatient;

        public PatientViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            tvPatientID = itemView.findViewById(R.id.tvPatientID);
            tvPatientDOB = itemView.findViewById(R.id.tvPatientDOB);
            tvPatientGender = itemView.findViewById(R.id.tvPatientGender);
            btnEditPatient = itemView.findViewById(R.id.btnEditPatient);
            btnDeletePatient = itemView.findViewById(R.id.btnDeletePatient);
        }
    }

    public void setPatientList(List<Patient> newPatientList) {
        this.patientList = newPatientList;
        notifyDataSetChanged();
    }
}


