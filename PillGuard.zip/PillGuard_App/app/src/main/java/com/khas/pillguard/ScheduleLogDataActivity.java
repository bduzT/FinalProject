package com.khas.pillguard;

import android.os.Bundle;
import android.view.LayoutInflater;
import com.khas.pillguard.adapters.PatientLogAdapter;
import android.view.View;
import android.widget.TextView;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.Patient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScheduleLogDataActivity extends AppCompatActivity {

    private RecyclerView recyclerPatients;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_log_data);

        recyclerPatients = findViewById(R.id.recyclerPatients);
        recyclerPatients.setLayoutManager(new LinearLayoutManager(this));
        apiService = ApiClient.instance;

        loadPatients();
    }

    private void loadPatients() {
        apiService.getPatients().enqueue(new Callback<List<Patient>>() {
            @Override
            public void onResponse(Call<List<Patient>> call, Response<List<Patient>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    PatientLogAdapter adapter = new PatientLogAdapter(response.body(), patient -> showMedicationLog(patient));
                    recyclerPatients.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<Patient>> call, Throwable t) {
                // Handle failure
            }
        });
    }

    private void showMedicationLog(Patient patient) {
        apiService.getMedicationsByPatient(patient.getId()).enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    showMedicationDialog(patient, response.body());
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                // Handle failure
            }
        });
    }

    private void showMedicationDialog(Patient patient, List<Medication> medications) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_medication_readonly, null);

        TextView tvDetails = view.findViewById(R.id.tvMedicationDetails);
        StringBuilder sb = new StringBuilder();
        for (Medication med : medications) {
            sb.append("Name: ").append(med.getMedicationName()).append("\n");
            sb.append("Dosage: ").append(med.getDosage()).append("\n");
            sb.append("Time: ").append(med.getTimeOfDay()).append("\n");
            sb.append("Frequency: ").append(med.getFrequency()).append("\n");
            sb.append("Start: ").append(med.getStartDate()).append("\n");
            sb.append("End: ").append(med.getEndDate()).append("\n");
            sb.append("-------------------\n");
        }
        tvDetails.setText(sb.toString());

        new AlertDialog.Builder(this)
                .setTitle(patient.getFirstName() + " " + patient.getLastName())
                .setView(view)
                .setPositiveButton("Close", null)
                .show();
    }
}
