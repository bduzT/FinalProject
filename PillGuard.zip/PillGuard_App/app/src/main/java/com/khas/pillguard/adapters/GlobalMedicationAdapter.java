package com.khas.pillguard.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.khas.pillguard.R;
import com.khas.pillguard.models.Medication;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GlobalMedicationAdapter extends RecyclerView.Adapter<GlobalMedicationAdapter.MedicationViewHolder> {

    private List<Medication> medicationList;
    private Context context;
    private OnMedicationSelectedListener listener;

    public interface OnMedicationSelectedListener {
        void onMedicationSelected(Medication medication);
    }

    public GlobalMedicationAdapter(Context context, List<Medication> medicationList, OnMedicationSelectedListener listener) {
        this.context = context;
        this.medicationList = medicationList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_global_medication, parent, false);
        return new MedicationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationViewHolder holder, int position) {
        Medication medication = medicationList.get(position);

        holder.tvMedicationName.setText(medication.getMedicationName());
        holder.tvDosage.setText(medication.getDosage());

        holder.btnSelectMedication.setOnClickListener(v -> {
            if (listener != null) {
                listener.onMedicationSelected(medication);
            } else {
                Toast.makeText(context, "Listener not set", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return medicationList.size();
    }

    public static class MedicationViewHolder extends RecyclerView.ViewHolder {
        TextView tvMedicationName, tvDosage;
        Button btnSelectMedication;

        public MedicationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMedicationName = itemView.findViewById(R.id.tvMedicationName);
            tvDosage = itemView.findViewById(R.id.tvDosage);
            btnSelectMedication = itemView.findViewById(R.id.btnSelectMedication);
        }
    }

    public void updateList(List<Medication> newList) {
        medicationList = newList;
        notifyDataSetChanged();
    }
}
