package com.khas.pillguard;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.khas.pillguard.adapters.MedicationAdapter;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.dialogs.AddGlobalMedicationDialog;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.PatientResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MedicationDatabaseActivity extends AppCompatActivity {

    private RecyclerView recyclerMedication;
    private MedicationAdapter adapter;
    private List<Medication> medicationList = new ArrayList<>();
    private Button btnAddMedication;

    private ApiService apiService;
    private static final String TAG = "MedicationDBActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medication_database);

        recyclerMedication = findViewById(R.id.recyclerMedication);
        btnAddMedication = findViewById(R.id.btnAddMedication);

        apiService = ApiClient.instance;

        adapter = new MedicationAdapter(this, medicationList);
        recyclerMedication.setLayoutManager(new LinearLayoutManager(this));
        recyclerMedication.setAdapter(adapter);

        fetchAllMedications();

        btnAddMedication.setOnClickListener(v -> {
            AddGlobalMedicationDialog dialog = new AddGlobalMedicationDialog(this, medication -> {
                if (medication != null) {
                    medication.setQrCode("QR_" + System.currentTimeMillis());
                    medication.setActive(true);

                    Log.d(TAG, "Medication Body: " + new Gson().toJson(medication));

                    apiService.addGlobalMedication(medication).enqueue(new Callback<PatientResponse>() {
                        @Override
                        public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                            if (response.isSuccessful()) {
                                Toast.makeText(MedicationDatabaseActivity.this, "Medication added to pool", Toast.LENGTH_SHORT).show();
                                fetchAllMedications();
                            } else {
                                Log.e(TAG, "Failed to add medication: " + response.code());
                                Toast.makeText(MedicationDatabaseActivity.this, "Failed to add medication", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<PatientResponse> call, Throwable t) {
                            Log.e(TAG, "Error adding medication: " + t.getMessage());
                            Toast.makeText(MedicationDatabaseActivity.this, "Server error", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
            dialog.show();
        });
    }

    private void fetchAllMedications() {
        apiService.getAllMedications().enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    medicationList.clear();
                    medicationList.addAll(response.body());
                    adapter.setMedicationList(medicationList);
                } else {
                    Toast.makeText(MedicationDatabaseActivity.this, "Failed to fetch medications", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Log.e(TAG, "API error: " + t.getMessage());
                Toast.makeText(MedicationDatabaseActivity.this, "Server error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
