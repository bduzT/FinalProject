package com.khas.pillguard.models;

import kotlin.text.UStringsKt;

public class User {
    private int id;
    private String fullName;
    private String dateOfBirth;
    private String contact;
    private byte[] photoBytes;
    private String someOtherField;

    public User(int id, String fullName, String dateOfBirth, String contact, byte[] photoBytes) {
        this.id = id;
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
        this.contact = contact;
        this.photoBytes = photoBytes;
    }

    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getSomeOtherField() {
        return someOtherField;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getContact() {
        return contact;
    }

    public byte[] getPhotoBytes() {
        return photoBytes;
    }
}
