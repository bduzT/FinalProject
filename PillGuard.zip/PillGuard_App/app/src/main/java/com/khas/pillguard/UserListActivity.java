package com.khas.pillguard;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.adapters.UserAdapter;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.CaregiverResponse;
import com.khas.pillguard.models.PatientResponse;
import com.khas.pillguard.models.Patient;
import com.khas.pillguard.models.Caregiver;
import com.khas.pillguard.models.UserModel;
import com.khas.pillguard.helpers.DatabaseControl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.CountDownLatch;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.util.Log;

public class UserListActivity extends AppCompatActivity implements UserAdapter.OnUserActionListener {

    private static final String TAG = "UserListActivity";

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<UserModel> userList;
    private DatabaseControl dbHelper;
    private Button btnAddNurse;
    private RadioGroup radioGroupUserType;

    private String currentFilter = "All";
    private ApiService apiService;
    private ExecutorService executorService;

    private static final int REQUEST_READ_EXTERNAL_STORAGE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        recyclerView = findViewById(R.id.recyclerView);
        btnAddNurse = findViewById(R.id.btnAddNurse);
        radioGroupUserType = findViewById(R.id.radioGroupUserType);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userList = new ArrayList<>();
        userAdapter = new UserAdapter(userList, this);
        recyclerView.setAdapter(userAdapter);

        dbHelper = new DatabaseControl(this);
        apiService = ApiClient.instance;
        executorService = Executors.newSingleThreadExecutor();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_READ_EXTERNAL_STORAGE);
        }

        btnAddNurse.setOnClickListener(v -> {
            Intent intent = new Intent(UserListActivity.this, AddNurseActivity.class);
            startActivity(intent);
        });

        radioGroupUserType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioAll) currentFilter = "All";
            else if (checkedId == R.id.radioPatients) currentFilter = "Patients";
            else if (checkedId == R.id.radioNurses) currentFilter = "Nurses";
            fetchUsersFromApiAndLoad();
        });

        fetchUsersFromApiAndLoad();
    }

    private void fetchUsersFromApiAndLoad() {
        CountDownLatch latch = new CountDownLatch(2);

        apiService.getCaregivers().enqueue(new Callback<List<Caregiver>>() {
            @Override
            public void onResponse(Call<List<Caregiver>> call, Response<List<Caregiver>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    executorService.execute(() -> {
                        updateLocalDatabaseCaregivers(response.body());
                        latch.countDown();
                        if (latch.getCount() == 0) runOnUiThread(() -> loadUsers());
                    });
                } else {
                    latch.countDown();
                    if (latch.getCount() == 0) runOnUiThread(() -> loadUsers());
                }
            }

            @Override
            public void onFailure(Call<List<Caregiver>> call, Throwable t) {
                latch.countDown();
                if (latch.getCount() == 0) runOnUiThread(() -> loadUsers());
            }
        });

        apiService.getPatients().enqueue(new Callback<List<Patient>>() {
            @Override
            public void onResponse(Call<List<Patient>> call, Response<List<Patient>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    executorService.execute(() -> {
                        updateLocalDatabasePatients(response.body());
                        latch.countDown();
                        if (latch.getCount() == 0) runOnUiThread(() -> loadUsers());
                    });
                } else {
                    latch.countDown();
                    if (latch.getCount() == 0) runOnUiThread(() -> loadUsers());
                }
            }

            @Override
            public void onFailure(Call<List<Patient>> call, Throwable t) {
                latch.countDown();
                if (latch.getCount() == 0) runOnUiThread(() -> loadUsers());
            }
        });
    }

    private void updateLocalDatabaseCaregivers(List<Caregiver> caregivers) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("Caregiver", null, null);
            for (Caregiver caregiver : caregivers) {
                ContentValues values = new ContentValues();
                values.put("CaregiverID", caregiver.getCaregiverId());
                values.put("FirstName", caregiver.getFirstName());
                values.put("LastName", caregiver.getLastName());
                values.put("ContactInfo", caregiver.getContactInfo());
                values.put("DateOfBirth", caregiver.getDateOfBirth());
                values.put("profile_picture_path", caregiver.getPhoto());
                values.put("AdminID", caregiver.getAdminId());
                values.put("Username", caregiver.getUsername());
                values.put("Password", caregiver.getPassword());
                db.insertWithOnConflict("Caregiver", null, values, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private void updateLocalDatabasePatients(List<Patient> patients) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("Patient", null, null);
            for (Patient patient : patients) {
                ContentValues values = new ContentValues();
                values.put("PatientID", patient.getId());
                values.put("FirstName", patient.getFirstName());
                values.put("LastName", patient.getLastName());
                values.put("DateOfBirth", patient.getDateOfBirth());
                values.put("Gender", patient.getGender());
                values.put("Photo", patient.getPhoto());
                values.put("CaregiverID", patient.getCaregiverId());
                values.put("FaceData", patient.getFaceData());
                db.insertWithOnConflict("Patient", null, values, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private void loadUsers() {
        executorService.execute(() -> {
            List<UserModel> loadedUsers = new ArrayList<>();
            if (currentFilter.equals("Nurses")) {
                loadedUsers.addAll(dbHelper.getAllCaregiversAsUsers());
            } else if (currentFilter.equals("Patients")) {
                loadedUsers.addAll(dbHelper.getAllPatientsAsUsers());
            } else {
                loadedUsers.addAll(dbHelper.getAllCaregiversAsUsers());
                loadedUsers.addAll(dbHelper.getAllPatientsAsUsers());
            }

            runOnUiThread(() -> {
                userList.clear();
                userList.addAll(loadedUsers);
                Collections.sort(userList, (u1, u2) -> (u1.getFirstName() + u1.getLastName())
                        .compareToIgnoreCase(u2.getFirstName() + u2.getLastName()));
                userAdapter.notifyDataSetChanged();
            });
        });
    }

    @Override
    public void onEditClick(int userId, String userType) {
        Intent intent = new Intent(this, EditUserActivity.class);
        if (userType.equals("Nurse")) {
            intent.putExtra("caregiverId", userId);
            intent.putExtra("userType", "Nurse");
        } else if (userType.equals("Patient")) {
            intent.putExtra("patientId", userId);
            intent.putExtra("userType", "Patient");
        }
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(int userId, String userType) {
        executorService.execute(() -> {
            if ("Nurse".equals(userType)) {
                apiService.deleteCaregiver(userId).enqueue(new Callback<CaregiverResponse>() {
                    @Override
                    public void onResponse(Call<CaregiverResponse> call, Response<CaregiverResponse> response) {
                        if (response.isSuccessful()) {
                            dbHelper.deleteCaregiver(userId);
                            runOnUiThread(() -> loadUsers());
                        }
                    }

                    @Override
                    public void onFailure(Call<CaregiverResponse> call, Throwable t) {}
                });
            } else if ("Patient".equals(userType)) {
                apiService.deletePatient(userId).enqueue(new Callback<PatientResponse>() {
                    @Override
                    public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                        if (response.isSuccessful()) {
                            dbHelper.deletePatient(userId);
                            runOnUiThread(() -> loadUsers());
                        }
                    }

                    @Override
                    public void onFailure(Call<PatientResponse> call, Throwable t) {}
                });
            }
        });
    }

    @Override
    public void onViewDetailsClick(int userId, String userType) {
        Toast.makeText(this, "Details for " + userType + ": " + userId, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fetchUsersFromApiAndLoad();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdownNow();
    }
}
