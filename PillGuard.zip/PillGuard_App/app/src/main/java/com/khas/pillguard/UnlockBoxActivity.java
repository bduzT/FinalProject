package com.khas.pillguard;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.PatientResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UnlockBoxActivity extends AppCompatActivity {

    private EditText etUnlockPassword;
    private Button btnUnlock;
    private ApiService apiService;
    private int patientId;
    private boolean nftVerified = false; // NFT doğrulaması simülasyonu

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unlock_box);

        etUnlockPassword = findViewById(R.id.etUnlockPassword);
        btnUnlock = findViewById(R.id.btnUnlock);

        apiService = ApiClient.instance;
        patientId = getIntent().getIntExtra("patientId", -1);

        if (patientId == -1) {
            Toast.makeText(this, "Patient ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // --- NFT kontrolü simülasyonu ---
        simulateNFTVerification();

        // --- Eğer NFT başarısızsa, kullanıcı manuel şifre girerek açabilir ---
        btnUnlock.setOnClickListener(v -> {
            if (!nftVerified) {
                String password = etUnlockPassword.getText().toString().trim();
                if (password.equals("1234")) {  // Gerçek sistemde hashli kontrol yapılmalı
                    unlockBox();
                } else {
                    Toast.makeText(this, "Invalid password", Toast.LENGTH_SHORT).show();
                }
            } else {
                unlockBox(); // NFT başarılıysa zaten şifreye gerek kalmadan açar
            }
        });
    }

    private void simulateNFTVerification() {
        // Gerçek senaryoda burada blockchain bağlantısı kurulup doğrulama yapılır
        // Şimdilik 2 saniyelik gecikmeyle sonucu veriyoruz
        btnUnlock.setEnabled(false);
        etUnlockPassword.setVisibility(View.GONE);

        Toast.makeText(this, "Checking NFT ownership...", Toast.LENGTH_SHORT).show();

        new android.os.Handler().postDelayed(() -> {
            nftVerified = false; // ← NFT doğrulaması başarısız gibi gösteriyoruz
            btnUnlock.setEnabled(true);
            etUnlockPassword.setVisibility(View.VISIBLE);
            Toast.makeText(this, "NFT verification failed. Please enter password.", Toast.LENGTH_LONG).show();
        }, 2000);
    }

    private void unlockBox() {
        apiService.unlockBox(patientId).enqueue(new Callback<PatientResponse>() {
            @Override
            public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(UnlockBoxActivity.this, "Pill box unlocked", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UnlockBoxActivity.this, "Failed to unlock", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PatientResponse> call, Throwable t) {
                Toast.makeText(UnlockBoxActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
