package com.khas.pillguard.adapters;
import com.khas.pillguard.EditGlobalMedicationDialog;


import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.khas.pillguard.R;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.dialogs.AddGlobalMedicationDialog;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.PatientResponse;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MedicationAdapter extends RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder> {

    private List<Medication> medicationList;
    private Context context;
    private ApiService apiService;
    private boolean readonly;

    public MedicationAdapter(Context context, List<Medication> medicationList) {
        this(context, medicationList, false);
    }

    public MedicationAdapter(Context context, List<Medication> medicationList, boolean readonly) {
        this.context = context;
        this.medicationList = medicationList;
        this.readonly = readonly;
        this.apiService = ApiClient.instance;
    }

    @NonNull
    @Override
    public MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medication, parent, false);
        return new MedicationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationViewHolder holder, int position) {
        Medication medication = medicationList.get(position);

        holder.tvMedicationName.setText(medication.getMedicationName());

        String statusText = "Dosage: " + medication.getDosage();
        holder.tvStatus.setText(statusText);

        if (!readonly) {
            holder.btnEdit.setOnClickListener(v -> editMedication(medication, position));
            holder.btnDelete.setOnClickListener(v -> deleteMedication(medication, position));
        } else {
            holder.btnEdit.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return medicationList.size();
    }

    static class MedicationViewHolder extends RecyclerView.ViewHolder {
        TextView tvMedicationName, tvStatus;
        Button btnEdit, btnDelete;

        public MedicationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMedicationName = itemView.findViewById(R.id.tvMedicationName);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    private void editMedication(Medication medication, int position) {
        EditGlobalMedicationDialog dialog = new EditGlobalMedicationDialog(context, medication, updatedMedication -> {
            if (updatedMedication != null) {
                medicationList.set(position, updatedMedication);
                notifyItemChanged(position);
                Toast.makeText(context, "Medication updated", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }

    private void deleteMedication(Medication medication, int position) {
        int medicationId = medication.getId(); // Global medication ID
        apiService.deleteGlobalMedication(medicationId).enqueue(new Callback<PatientResponse>() {
            @Override
            public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                if (response.isSuccessful()) {
                    medicationList.remove(position);
                    notifyItemRemoved(position);
                    Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to delete", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PatientResponse> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setMedicationList(List<Medication> newMedicationList) {
        this.medicationList = newMedicationList;
        notifyDataSetChanged();
    }

    public void addMedication(Medication medication) {
        medicationList.add(medication);
        notifyItemInserted(medicationList.size() - 1);
    }

    public void setReadonly(boolean readonly) {
        this.readonly = readonly;
    }
}
