package com.khas.pillguard.models;
import com.google.gson.annotations.SerializedName;

public class LoginResponse {

    @SerializedName("message")
    private String message;

    // Assuming your Flask API returns 'admin_id' for admin login
    // and 'caregiver_id' for caregiver login.
    // We can include both fields and Gson will handle mapping based on the response.
    @SerializedName("admin_id")
    private int adminId;

    @SerializedName("caregiver_id")
    private int caregiverId; // Added for caregiver login response

    @SerializedName("patient_id")
    private int patientId; // ❌ EKSİK

    public int getPatientId() {     // ❌ EKSİK
        return patientId;
    }

    // Default constructor for Gson
    public LoginResponse() {
    }

    // Constructor (optional, for manual creation)
    public LoginResponse(String message, int adminId, int caregiverId) {
        this.message = message;
        this.adminId = adminId;
        this.caregiverId = caregiverId;
    }

    // --- Getters ---
    public String getMessage() {
        return message;
    }

    // Getter for admin ID
    public int getAdminId() {
        return adminId;
    }

    // Getter for caregiver ID
    public int getCaregiverId() {
        return caregiverId;
    }


    // --- Setters (Optional) ---
    public void setMessage(String message) {
        this.message = message;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public void setCaregiverId(int caregiverId) {
        this.caregiverId = caregiverId;
    }
}
