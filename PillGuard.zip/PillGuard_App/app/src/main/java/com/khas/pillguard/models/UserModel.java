package com.khas.pillguard.models;

// This model will represent a generic user (either Patient or Caregiver)
public class UserModel {

    private int id; // The unique ID (either PatientID or CaregiverID)
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String gender; // Relevant for Patient, might be null for Caregiver depending on your data
    private String photoPath; // Path or URL to the profile picture
    private int associatedId; // The actual ID (PatientID or CaregiverID)
    private String userType; // "Patient" or "Nurse"
    private int adminId; // Relevant for Caregiver, might be 0 or null for Patient
    private String username; // Relevant for Caregiver (email), might be null for Patient
    private String password; // Relevant for Caregiver (hashed password), should not be sent to UI typically

    // Constructor for creating a UserModel (can be adapted based on your data sources)
    public UserModel(int id, String firstName, String lastName, String dateOfBirth, String gender, String photoPath, int associatedId, String userType, int adminId, String username, String password) {
        this.id = id; // This might be a list index or a temporary ID, consider if needed
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.photoPath = photoPath;
        this.associatedId = associatedId; // Store the actual unique ID here
        this.userType = userType;
        this.adminId = adminId;
        this.username = username;
        this.password = password; // Be cautious with sending passwords
    }

    // --- Getters ---

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public int getAssociatedId() {
        return associatedId;
    }

    public String getUserType() {
        return userType;
    }

    public int getAdminId() {
        return adminId;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // --- Setters (Optional, if you need to modify the model after creation) ---

    public void setId(int id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public void setAssociatedId(int associatedId) {
        this.associatedId = associatedId;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
