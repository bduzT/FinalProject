package com.khas.pillguard.helpers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log; // Import Log

import com.khas.pillguard.models.Caregiver;
import com.khas.pillguard.models.Patient; // Still needed if you have Patient-specific operations elsewhere

// Import the UserModel
import com.khas.pillguard.models.UserModel;


import java.util.ArrayList;
import java.util.List;

public class DatabaseControl extends SQLiteOpenHelper {

    // Corrected database name to "pillgaurd.db"
    private static final String DB_NAME = "pillgaurd.db";
    // **IMPORTANT:** Increased version to 3 to trigger onUpgrade if needed,
    // but uninstall/reinstall is the most reliable way to get the latest schema during development.
    private static final int DATABASE_VERSION = 3;

    private final Context myContext;
    // We no longer store a direct SQLiteDatabase instance here
    // private SQLiteDatabase myDatabase;

    public DatabaseControl(Context context) {
        super(context, DB_NAME, null, DATABASE_VERSION);
        this.myContext = context;
        // The database path is managed by SQLiteOpenHelper internally now
        Log.d("DatabaseControl", "DatabaseHelper initialized for: " + DB_NAME + " Version: " + DATABASE_VERSION);
    }

    // Removed manual openDatabase() method
    // Removed ensureDatabaseOpen() method

    @Override
    public synchronized void close() {
        // Call the superclass close method, which handles closing the database instance
        super.close();
        Log.i("DatabaseControl", "DatabaseHelper closed.");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // THIS IS CRUCIAL: Create your tables here if the database does not exist.
        // This method is called when the database is created for the first time.

        Log.i("DatabaseControl", "onCreate called - Creating database tables.");

        // Create Caregiver table (Added Username and Password columns and UNIQUE constraint)
        String CREATE_CAREGIVER_TABLE = "CREATE TABLE Caregiver (" +
                "CaregiverID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "FirstName TEXT," +
                "LastName TEXT," +
                "ContactInfo TEXT," +
                "DateOfBirth TEXT," +
                "profile_picture_path TEXT," +
                "AdminID INTEGER," +
                "Username TEXT UNIQUE," + // Added Username column with UNIQUE constraint
                "Password TEXT" + // Added Password column
                ");";
        db.execSQL(CREATE_CAREGIVER_TABLE);
        Log.i("DatabaseControl", "Caregiver table created with Username and Password");


        // Create Patient table (assuming this structure based on your insert/get methods)
        String CREATE_PATIENT_TABLE = "CREATE TABLE Patient (" +
                "PatientID INTEGER PRIMARY KEY," + // PatientID is provided, not AUTOINCREMENT
                "FirstName TEXT," +
                "LastName TEXT," +
                "DateOfBirth TEXT," +
                "Gender TEXT," +
                "Photo TEXT," + // Assuming 'Photo' stores the path for patients
                "CaregiverID INTEGER," +
                "FaceData TEXT" +
                ");";
        db.execSQL(CREATE_PATIENT_TABLE);
        Log.i("DatabaseControl", "Patient table created");

        // Create other tables if you have them (Admin, Medication, LockSystem)
        // Example for Admin table (based on your Flask code)
        String CREATE_ADMIN_TABLE = "CREATE TABLE Admin (" +
                "AdminID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "Username TEXT UNIQUE," + // Username should likely be unique
                "Password TEXT" +
                ");";
        db.execSQL(CREATE_ADMIN_TABLE);
        Log.i("DatabaseControl", "Admin table created");

        // Add CREATE TABLE statements for Medication and LockSystem if they exist
        // based on your Flask API endpoints.
        // Example (adjust column names and types based on your models/Flask):
        String CREATE_MEDICATION_TABLE = "CREATE TABLE Medication (" +
                "MedicationID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "PatientID INTEGER," +
                "CaregiverID INTEGER," +
                "MedicationName TEXT," +
                "Description TEXT," +
                "QRCode TEXT," +
                "Dosage TEXT," +
                "Frequency TEXT," +
                "TimeOfDay TEXT," +
                "StartDate TEXT," +
                "EndDate TEXT," +
                "StorageStatus TEXT," +
                "LastTakenTime TEXT," +
                "IsActive INTEGER" + // 0 for false, 1 for true
                ");";
        db.execSQL(CREATE_MEDICATION_TABLE);
        Log.i("DatabaseControl", "Medication table created");

        String CREATE_LOCKSYSTEM_TABLE = "CREATE TABLE LockSystem (" +
                "LockID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "PatientID INTEGER," +
                "LockStatus TEXT," +
                "OpenTime TEXT," +
                "CloseTime TEXT," +
                "Duration TEXT," +
                "TimeWindowStart TEXT," +
                "TimeWindowEnd TEXT," +
                "AllowAccess INTEGER" + // 0 for false, 1 for true
                ");";
        db.execSQL(CREATE_LOCKSYSTEM_TABLE);
        Log.i("DatabaseControl", "LockSystem table created");

        // Add Foreign Key constraints if not already defined (recommended)
        // Note: Adding FKs in ALTER TABLE can be complex. Defining them in CREATE TABLE is easier.
        // If you add FKs here, ensure the referenced tables exist first.
        // Example for Patient table referencing Caregiver:
        // db.execSQL("CREATE TABLE Patient (...) FOREIGN KEY (CaregiverID) REFERENCES Caregiver(CaregiverID) ON DELETE SET NULL;");
        // Example for Medication table referencing Patient and Caregiver:
        // db.execSQL("CREATE TABLE Medication (...) FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE, FOREIGN KEY (CaregiverID) REFERENCES Caregiver(CaregiverID) ON DELETE SET NULL;");
        // Example for LockSystem table referencing Patient:
        // db.execSQL("CREATE TABLE LockSystem (...) FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE;");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades here.
        Log.i("DatabaseControl", "onUpgrade called from version " + oldVersion + " to " + newVersion);
        // Example upgrade: Add Username and Password columns if upgrading from version 2
        if (oldVersion < 3) {
            try {
                // Check if columns exist before adding to avoid errors on repeated upgrades
                Cursor cursor = db.rawQuery("PRAGMA table_info(Caregiver)", null);
                boolean usernameExists = false;
                boolean passwordExists = false;
                if (cursor != null) {
                    int nameColumnIndex = cursor.getColumnIndex("name"); // Get index for the column name
                    if (nameColumnIndex != -1) { // Check if "name" column exists in PRAGMA output
                        while (cursor.moveToNext()) {
                            String columnName = cursor.getString(nameColumnIndex); // Safely get column name
                            if ("Username".equals(columnName)) {
                                usernameExists = true;
                            }
                            if ("Password".equals(columnName)) {
                                passwordExists = true;
                            }
                        }
                    }
                    cursor.close();
                }

                if (!usernameExists) {
                    db.execSQL("ALTER TABLE Caregiver ADD COLUMN Username TEXT UNIQUE;");
                    Log.i("DatabaseControl", "Added Username column to Caregiver table");
                } else {
                    Log.i("DatabaseControl", "Username column already exists in Caregiver table");
                }

                if (!passwordExists) {
                    db.execSQL("ALTER TABLE Caregiver ADD COLUMN Password TEXT;");
                    Log.i("DatabaseControl", "Added Password column to Caregiver table");
                } else {
                    Log.i("DatabaseControl", "Password column already exists in Caregiver table");
                }

            } catch (SQLException e) {
                Log.e("DatabaseControl", "Error adding columns during upgrade", e);
            }
        }
        // If you have more version changes, add more 'if' blocks.
        // Example:
        // if (oldVersion < 4) {
        //     db.execSQL("ALTER TABLE YourTable ADD COLUMN NewColumn TEXT;");
        // }
    }

    // Insert a new caregiver into the database (Updated to include username and password)
    public void insertCaregiver(int caregiverId, String firstName, String lastName, String contactInfo, String dateOfBirth, String photoPath, int adminId, String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("CaregiverID", caregiverId); // Include ID when inserting from API
            values.put("FirstName", firstName);
            values.put("LastName", lastName);
            values.put("ContactInfo", contactInfo);
            values.put("DateOfBirth", dateOfBirth);
            values.put("profile_picture_path", photoPath); // Store the path
            values.put("AdminID", adminId);
            values.put("Username", username); // Insert username
            values.put("Password", password); // Insert password

            long result = db.insertWithOnConflict("Caregiver", null, values, SQLiteDatabase.CONFLICT_REPLACE); // Use CONFLICT_REPLACE to update if ID exists
            if (result == -1) {
                Log.e("DatabaseControl", "Error inserting/updating caregiver");
            } else {
                Log.i("DatabaseControl", "Caregiver inserted/updated with row ID: " + result);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e("DatabaseControl", "Exception during caregiver insertion/update", e);
        } finally {
            db.endTransaction();
        }
    }

    // Update an existing caregiver in the database (You might use this for local edits not from API sync)
    // Note: This method is not currently used by updateLocalDatabaseCaregivers, which clears and re-inserts.
    public void updateCaregiver(int caregiverId, String firstName, String lastName, String contactInfo, String dateOfBirth, String photoPath, int adminId, String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("FirstName", firstName);
        values.put("LastName", lastName);
        values.put("ContactInfo", contactInfo);
        values.put("DateOfBirth", dateOfBirth);
        if (photoPath != null) {
            values.put("profile_picture_path", photoPath); // Store the path
        }
        values.put("AdminID", adminId);
        values.put("Username", username);
        values.put("Password", password);

        int rowsAffected = db.update("Caregiver", values, "CaregiverID = ?", new String[]{String.valueOf(caregiverId)});
        Log.i("DatabaseControl", "Caregiver updated. Rows affected: " + rowsAffected);
    }

    // Delete a caregiver from the database by their ID
    public void deleteCaregiver(int caregiverId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction(); // Added transaction for delete
        try {
            int rowsDeleted = db.delete("Caregiver", "CaregiverID = ?", new String[]{String.valueOf(caregiverId)});
            Log.i("DatabaseControl", "Caregiver deleted from local DB. Rows deleted: " + rowsDeleted);
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e("DatabaseControl", "Exception during local caregiver deletion", e);
        } finally {
            db.endTransaction();
        }
    }

    // Get all caregivers from the database and return as UserModel objects
    public List<UserModel> getAllCaregiversAsUsers() { // Changed return type and name
        SQLiteDatabase db = this.getReadableDatabase();
        List<UserModel> userList = new ArrayList<>(); // Use UserModel list
        Cursor cursor = null;

        try {
            // Select all relevant columns for creating a UserModel that represents a Caregiver
            Cursor caregiverCursor = db.rawQuery("SELECT CaregiverID, FirstName, LastName, DateOfBirth, profile_picture_path, AdminID, Username, Password FROM Caregiver", null);

            if (caregiverCursor != null && caregiverCursor.moveToFirst()) {
                int idIndex = caregiverCursor.getColumnIndex("CaregiverID");
                int firstNameIndex = caregiverCursor.getColumnIndex("FirstName");
                int lastNameIndex = caregiverCursor.getColumnIndex("LastName");
                int dobIndex = caregiverCursor.getColumnIndex("DateOfBirth");
                int photoPathIndex = caregiverCursor.getColumnIndex("profile_picture_path");
                int adminIdIndex = caregiverCursor.getColumnIndex("AdminID");
                int usernameIndex = caregiverCursor.getColumnIndex("Username");
                int passwordIndex = caregiverCursor.getColumnIndex("Password");

                do {
                    // Check if column index is valid before getting value
                    int id = (idIndex != -1) ? caregiverCursor.getInt(idIndex) : 0;
                    String firstName = (firstNameIndex != -1) ? caregiverCursor.getString(firstNameIndex) : "";
                    String lastName = (lastNameIndex != -1) ? caregiverCursor.getString(lastNameIndex) : "";
                    String dob = (dobIndex != -1) ? caregiverCursor.getString(dobIndex) : "";
                    String photoPath = (photoPathIndex != -1) ? caregiverCursor.getString(photoPathIndex) : null;
                    int adminId = (adminIdIndex != -1) ? caregiverCursor.getInt(adminIdIndex) : 0;
                    String username = (usernameIndex != -1) ? caregiverCursor.getString(usernameIndex) : "";
                    String password = (passwordIndex != -1) ? caregiverCursor.getString(passwordIndex) : "";


                    // Create a UserModel object for a Nurse
                    // Use the UserModel constructor
                    userList.add(new UserModel(id, firstName, lastName, dob, null, photoPath, id, "Nurse", adminId, username, password)); // Pass id as associatedId
                } while (caregiverCursor.moveToNext());
            }
            if (caregiverCursor != null) caregiverCursor.close(); // Close cursor
        } catch (Exception e) {
            Log.e("DatabaseControl", "Exception during getAllCaregiversAsUsers", e); // Updated log message
        }

        return userList;
    }


    // Insert a new patient into the database.
    public void insertPatient(int patientId, String firstName, String lastName, String dateOfBirth, String gender, String photoPath, int caregiverId, String faceData) { // Added patientId and changed photo to photoPath
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("PatientID", patientId); // Include PatientID for insertion
            values.put("FirstName", firstName);
            values.put("LastName", lastName);
            values.put("DateOfBirth", dateOfBirth);
            values.put("Gender", gender);
            values.put("Photo", photoPath); // Assuming 'Photo' stores the path for patients
            values.put("CaregiverID", caregiverId);
            values.put("FaceData", faceData);
            long result = db.insertWithOnConflict("Patient", null, values, SQLiteDatabase.CONFLICT_REPLACE); // Use CONFLICT_REPLACE for patient updates
            if (result == -1) {
                Log.e("DatabaseControl", "Error inserting/updating patient");
            } else {
                Log.i("DatabaseControl", "Patient inserted/updated with row ID: " + result);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e("DatabaseControl", "Exception during patient insertion/update", e);
        } finally {
            db.endTransaction();
        }
    }

    // Get all patients from the database and return as UserModel objects
    public List<UserModel> getAllPatientsAsUsers() { // Changed return type and name
        SQLiteDatabase db = this.getReadableDatabase();
        List<UserModel> userList = new ArrayList<>(); // Use UserModel list
        Cursor cursor = null;

        try {
            // Select all relevant columns for creating a UserModel that represents a Patient
            Cursor patientCursor = db.rawQuery("SELECT PatientID, FirstName, LastName, DateOfBirth, Gender, Photo, CaregiverID, FaceData FROM Patient", null);
            if (patientCursor != null && patientCursor.moveToFirst()) {
                int idIndex = patientCursor.getColumnIndex("PatientID");
                int firstNameIndex = patientCursor.getColumnIndex("FirstName");
                int lastNameIndex = patientCursor.getColumnIndex("LastName");
                int dobIndex = patientCursor.getColumnIndex("DateOfBirth");
                int genderIndex = patientCursor.getColumnIndex("Gender");
                int photoIndex = patientCursor.getColumnIndex("Photo"); // Assuming this column stores the photo path/URL
                int caregiverIdIndex = patientCursor.getColumnIndex("CaregiverID");
                int faceDataIndex = patientCursor.getColumnIndex("FaceData");

                do {
                    // Check if column index is valid before getting value
                    int id = (idIndex != -1) ? patientCursor.getInt(idIndex) : 0;
                    String firstName = (firstNameIndex != -1) ? patientCursor.getString(firstNameIndex) : "";
                    String lastName = (lastNameIndex != -1) ? patientCursor.getString(lastNameIndex) : "";
                    String dob = (dobIndex != -1) ? patientCursor.getString(dobIndex) : "";
                    String gender = (genderIndex != -1) ? patientCursor.getString(genderIndex) : "";
                    // Assuming Photo column stores the path/URL
                    String photoFilePath = (photoIndex != -1) ? patientCursor.getString(photoIndex) : null;
                    int caregiverId = (caregiverIdIndex != -1) ? patientCursor.getInt(caregiverIdIndex) : -1;
                    String faceData = (faceDataIndex != -1) ? patientCursor.getString(faceDataIndex) : null;

                    // Create a UserModel object for a Patient
                    // Use the UserModel constructor
                    userList.add(new UserModel(id, firstName, lastName, dob, gender, photoFilePath, id, "Patient", -1, null, null)); // Pass id as associatedId
                } while (patientCursor.moveToNext());
            }
            if (patientCursor != null) patientCursor.close(); // Close cursor
        } catch (Exception e) {
            Log.e("DatabaseControl", "Exception during getAllPatientsAsUsers", e); // Updated log message
        }

        return userList;
    }

    // Delete a patient from the database by their ID (Example, you might need this later)
    public void deletePatient(int patientId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction(); // Added transaction for delete
        try {
            int rowsDeleted = db.delete("Patient", "PatientID = ?", new String[]{String.valueOf(patientId)});
            Log.i("DatabaseControl", "Patient deleted from local DB. Rows deleted: " + rowsDeleted);
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e("DatabaseControl", "Exception during local patient deletion", e);
        } finally {
            db.endTransaction();
        }
    }

    // Removed unused methods
    // public void insertNurse(String name, String surname, String contact, String dob, byte[] selectedImageBytes) { }
    // public void createDatabase() { }
}
