package com.khas.pillguard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CaregiverDashboardActivity extends AppCompatActivity {

    private TextView tvWelcomeCaregiver;
    private Button btnAddPatient;
    private Button btnViewPatientList;
    private Button btnViewPillList;
    private Button btnEditProfile;
    private Button btnLogoutCaregiver;

    private static final String PREFS_NAME = "PillGuardPrefs";
    private static final String USER_ID_KEY = "userId";
    private static final String USER_TYPE_KEY = "userType";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caregiver_dashboard);

        tvWelcomeCaregiver = findViewById(R.id.tvWelcomeCaregiver);
        btnAddPatient = findViewById(R.id.btnAddPatient);
        btnViewPatientList = findViewById(R.id.btnViewPatientList);
        btnViewPillList = findViewById(R.id.btnViewPillList);
        btnEditProfile = findViewById(R.id.btnEditProfile);
        btnLogoutCaregiver = findViewById(R.id.btnLogoutCaregiver);

        tvWelcomeCaregiver.setText(R.string.welcome_caregiver);

        btnAddPatient.setOnClickListener(v -> {
            Intent intent = new Intent(CaregiverDashboardActivity.this, AddPatientActivity.class);
            startActivity(intent);
        });

        btnViewPatientList.setOnClickListener(v -> {
            Intent intent = new Intent(CaregiverDashboardActivity.this, ViewPatientListActivity.class);
            startActivity(intent);
        });

        btnViewPillList.setOnClickListener(v -> {
            Intent intent = new Intent(CaregiverDashboardActivity.this, PillScheduleActivity.class);
            startActivity(intent);
        });

        btnEditProfile.setOnClickListener(v -> {
            int currentCaregiverId = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(USER_ID_KEY, -1);
            if (currentCaregiverId != -1) {
                Intent intent = new Intent(CaregiverDashboardActivity.this, EditUserActivity.class);
                intent.putExtra("caregiverId", currentCaregiverId);
                intent.putExtra("userType", "Nurse");
                startActivity(intent);
            } else {
                Toast.makeText(CaregiverDashboardActivity.this, "Error: Caregiver ID not found.", Toast.LENGTH_SHORT).show();
            }
        });

        btnLogoutCaregiver.setOnClickListener(v -> logout());
    }

    private void logout() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(USER_ID_KEY);
        editor.remove(USER_TYPE_KEY);
        editor.apply();

        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(CaregiverDashboardActivity.this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
