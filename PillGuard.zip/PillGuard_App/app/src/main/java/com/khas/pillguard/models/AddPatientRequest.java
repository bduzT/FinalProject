package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class AddPatientRequest {

    // Patient Details
    @SerializedName("patient_id")
    private int patientId;
    @SerializedName("first_name")
    private String firstName;
    @SerializedName("last_name")
    private String lastName;
    @SerializedName("date_of_birth")
    private String dateOfBirth;
    @SerializedName("gender")
    private String gender;
    @SerializedName("caregiver_id")
    private int caregiverId;
    @SerializedName("face_data")
    private String faceData;

    // Lists for multiple medications and their associated lock times
    @SerializedName("medications")
    private List<Medication> medications;

    // Assuming a 1-to-1 correspondence between medication and lock system entry for simplicity
    // If a medication can have multiple lock windows, this needs adjustment.
    @SerializedName("lock_systems")
    private List<LockSystem> lockSystems;


    public AddPatientRequest(int patientId, String firstName, String lastName, String dateOfBirth, String gender, int caregiverId, String faceData, List<Medication> medications, List<LockSystem> lockSystems) {
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.caregiverId = caregiverId;
        this.faceData = faceData;
        this.medications = medications;
        this.lockSystems = lockSystems;
    }

    // Add getters (setters might not be needed if the object is created once)

    public int getPatientId() {
        return patientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public int getCaregiverId() {
        return caregiverId;
    }

    public String getFaceData() {
        return faceData;
    }

    public List<Medication> getMedications() {
        return medications;
    }

    public List<LockSystem> getLockSystems() {
        return lockSystems;
    }
}
