package com.khas.pillguard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class NurseInterfaceActivity extends AppCompatActivity {

    private Button btnAddPatient, btnViewPillList, btnViewPatientList, btnEditProfile, btnLogoutCaregiver;

    private String userRole = "nurse";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caregiver_dashboard);

        btnAddPatient = findViewById(R.id.btnAddPatient);
        btnViewPillList = findViewById(R.id.btnViewPillList);
        btnViewPatientList = findViewById(R.id.btnViewPatientList);
        btnEditProfile = findViewById(R.id.btnEditProfile);
        btnLogoutCaregiver = findViewById(R.id.btnLogoutCaregiver);


        btnAddPatient.setOnClickListener(v -> {
            Intent intent = new Intent(NurseInterfaceActivity.this, AddPatientActivity.class);
            startActivity(intent);
        });

        btnViewPillList.setOnClickListener(v -> {
            Intent intent = new Intent(NurseInterfaceActivity.this, ManageScheduleActivity.class);
            startActivity(intent);
        });

        btnViewPatientList.setOnClickListener(v -> {
            Intent intent = new Intent(NurseInterfaceActivity.this, UserListActivity.class);
            startActivity(intent);
        });

        btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(NurseInterfaceActivity.this, EditUserActivity.class);
            startActivity(intent);
        });

        btnLogoutCaregiver.setOnClickListener(v -> {
            Intent intent = new Intent(NurseInterfaceActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
