package com.khas.pillguard;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Caregiver;
import com.khas.pillguard.models.CaregiverResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditUserActivity extends AppCompatActivity {

    private static final String TAG = "EditUserActivity";
    private int userId;

    private EditText etFirstName, etLastName, etContactInfo, etDateOfBirth, etUsername, etPassword;
    private Button btnUploadPhoto, btnSaveChanges;
    private ImageView ivPhotoPreview;

    private ApiService apiService;
    private Uri currentPhotoUri;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        etFirstName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), lettersOnlyFilter});
        etLastName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), lettersOnlyFilter});
        etContactInfo.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        etDateOfBirth.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        etUsername.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        etPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});


        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        ivPhotoPreview = findViewById(R.id.ivPhotoPreview);

        apiService = ApiClient.instance;

        etFirstName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15), lettersOnlyFilter});
        etLastName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15), lettersOnlyFilter});
        etContactInfo.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15)});

        userId = getIntent().getIntExtra("caregiverId", -1);

        if (userId != -1) {
            loadUserDataFromApi(userId);
        } else {
            Toast.makeText(this, "No user ID provided.", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnUploadPhoto.setOnClickListener(v -> pickImage());
        btnSaveChanges.setOnClickListener(v -> saveChangesToApi());
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void loadUserDataFromApi(int id) {
        apiService.getCaregiverById(id).enqueue(new Callback<Caregiver>() {
            @Override
            public void onResponse(Call<Caregiver> call, Response<Caregiver> response) {
                if (response.isSuccessful() && response.body() != null) {
                    populateUI(response.body());
                } else {
                    Toast.makeText(EditUserActivity.this, "Failed to load user data.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onFailure(Call<Caregiver> call, Throwable t) {
                Toast.makeText(EditUserActivity.this, "Network error.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void populateUI(Caregiver caregiver) {
        etFirstName.setText(caregiver.getFirstName());
        etLastName.setText(caregiver.getLastName());
        etContactInfo.setText(caregiver.getContactInfo());
        etDateOfBirth.setText(caregiver.getDateOfBirth());
        etUsername.setText(caregiver.getUsername());
        etPassword.setText(caregiver.getPassword());

        // Local photo loading (optional)
        String photoPath = caregiver.getPhoto();
        if (photoPath != null && !photoPath.isEmpty()) {
            File photoFile = new File(photoPath);
            if (photoFile.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(photoFile.getAbsolutePath());
                ivPhotoPreview.setImageBitmap(bitmap);
            } else {
                ivPhotoPreview.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        }
    }

    private void saveChangesToApi() {
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String contactInfo = etContactInfo.getText().toString().trim();
        String dateOfBirth = etDateOfBirth.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (firstName.isEmpty() || lastName.isEmpty() || dateOfBirth.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        RequestBody firstNameBody = RequestBody.create(MediaType.parse("text/plain"), firstName);
        RequestBody lastNameBody = RequestBody.create(MediaType.parse("text/plain"), lastName);
        RequestBody contactInfoBody = RequestBody.create(MediaType.parse("text/plain"), contactInfo);
        RequestBody dateOfBirthBody = RequestBody.create(MediaType.parse("text/plain"), dateOfBirth);
        RequestBody usernameBody = RequestBody.create(MediaType.parse("text/plain"), username);
        RequestBody passwordBody = RequestBody.create(MediaType.parse("text/plain"), password);

        MultipartBody.Part photoPart = null;
        if (currentPhotoUri != null) {
            try {
                File photoFile = getFileFromUri(currentPhotoUri);
                RequestBody requestFile = RequestBody.create(MediaType.parse(getContentResolver().getType(currentPhotoUri)), photoFile);
                photoPart = MultipartBody.Part.createFormData("photo", photoFile.getName(), requestFile);
            } catch (IOException e) {
                Toast.makeText(this, "Error processing photo", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        apiService.updateCaregiver(userId, firstNameBody, lastNameBody, contactInfoBody, dateOfBirthBody, photoPart, usernameBody, passwordBody)
                .enqueue(new Callback<CaregiverResponse>() {
                    @Override
                    public void onResponse(Call<CaregiverResponse> call, Response<CaregiverResponse> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(EditUserActivity.this, "User updated", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(EditUserActivity.this, "Failed: " + response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<CaregiverResponse> call, Throwable t) {
                        Toast.makeText(EditUserActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private File getFileFromUri(Uri uri) throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File tempFile = File.createTempFile("JPEG_" + timeStamp, ".jpg", getExternalFilesDir(Environment.DIRECTORY_PICTURES));

        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             FileOutputStream outputStream = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, read);
            }
        }
        return tempFile;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            currentPhotoUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), currentPhotoUri);
                ivPhotoPreview.setImageBitmap(bitmap);
            } catch (IOException e) {
                Toast.makeText(this, "Image load failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private final InputFilter lettersOnlyFilter = (source, start, end, dest, dstart, dend) -> {
        if (!Pattern.compile("[a-zA-ZğüşıöçĞÜŞİÖÇ ]+").matcher(source).matches()) {
            return "";
        }
        return null;
    };
}
