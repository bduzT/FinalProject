package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;

public class CaregiverResponse {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}