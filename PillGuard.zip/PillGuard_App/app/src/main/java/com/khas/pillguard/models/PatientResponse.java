package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName; // Import SerializedName if your API uses different key names

public class PatientResponse {
    // Assuming the API response contains a "message" field
    @SerializedName("message") // Use SerializedName if the JSON key is different (e.g., "status")
    private String message;

    // Default constructor needed for Gson deserialization
    public PatientResponse() {
    }

    // Constructor (optional)
    public PatientResponse(String message) {
        this.message = message;
    }

    // Corrected return type to String
    public String getMessage() {
        return message;
    }

    // Setter (optional)
    public void setMessage(String message) {
        this.message = message;
    }
}
