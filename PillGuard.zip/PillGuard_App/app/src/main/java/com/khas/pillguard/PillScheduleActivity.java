package com.khas.pillguard;

import androidx.appcompat.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.Patient;
import com.khas.pillguard.models.PatientResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PillScheduleActivity extends AppCompatActivity {

    private EditText inputSearchPatient;
    private LinearLayout patientsContainer;
    private ApiService apiService;
    private List<Patient> allPatients = new ArrayList<>();
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pill_schedule);

        context = this;
        inputSearchPatient = findViewById(R.id.autoPatientSearch);
        patientsContainer = findViewById(R.id.medicationListContainer);
        apiService = ApiClient.instance;

        loadPatients();

        inputSearchPatient.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterPatients(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void loadPatients() {
        apiService.getPatients().enqueue(new Callback<List<Patient>>() {
            @Override
            public void onResponse(Call<List<Patient>> call, Response<List<Patient>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    allPatients = response.body();
                    displayPatients(allPatients);
                } else {
                    Toast.makeText(context, "Failed to fetch patients", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Patient>> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void filterPatients(String keyword) {
        List<Patient> filtered = new ArrayList<>();
        for (Patient p : allPatients) {
            String fullName = (p.getFirstName() + " " + p.getLastName()).toLowerCase();
            if (fullName.contains(keyword.toLowerCase())) {
                filtered.add(p);
            }
        }
        displayPatients(filtered);
    }

    private void displayPatients(List<Patient> patients) {
        patientsContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(context);

        for (Patient patient : patients) {
            View patientView = inflater.inflate(R.layout.item_patient_medications, patientsContainer, false);

            TextView tvPatientName = patientView.findViewById(R.id.tvPatientName);
            LinearLayout medicationsLayout = patientView.findViewById(R.id.medicationsList);
            Button btnAddMed = patientView.findViewById(R.id.btnAddMedication);
            Button btnRemoveMed = patientView.findViewById(R.id.btnRemoveMedication);

            tvPatientName.setText(patient.getFirstName() + " " + patient.getLastName());

            loadMedicationsForPatient(patient.getId(), medicationsLayout);

            btnAddMed.setOnClickListener(v -> {
                // Bu noktada kartlı yeni ekranı aç
                AssignMedicationDialog assignDialog = new AssignMedicationDialog(context, patient.getId());
                assignDialog.show();
            });

            btnRemoveMed.setOnClickListener(v -> showRemoveMedicationDialog(patient.getId()));

            patientsContainer.addView(patientView);
        }
    }

    private void loadMedicationsForPatient(int patientId, LinearLayout container) {
        apiService.getMedicationsByPatient(patientId).enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    container.removeAllViews();
                    for (Medication med : response.body()) {
                        View medView = LayoutInflater.from(context).inflate(R.layout.item_assign_medication, container, false);

                        TextView tvName = medView.findViewById(R.id.tvMedicationName);
                        TextView tvDosage = medView.findViewById(R.id.tvDosage);

                        tvName.setText(med.getMedicationName());
                        tvDosage.setText("Dosage: " + med.getDosage());

                        container.addView(medView);
                    }
                } else {
                    Toast.makeText(context, "No medications found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showRemoveMedicationDialog(int patientId) {
        apiService.getMedicationsByPatient(patientId).enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    List<Medication> meds = response.body();
                    String[] medNames = new String[meds.size()];
                    for (int i = 0; i < meds.size(); i++) {
                        medNames[i] = meds.get(i).getMedicationName();
                    }

                    new AlertDialog.Builder(context)
                            .setTitle("Remove Medication")
                            .setItems(medNames, (dialog, which) -> {
                                int medIdToDelete = meds.get(which).getMedicationId();
                                apiService.deleteMedication(medIdToDelete).enqueue(new Callback<PatientResponse>() {
                                    @Override
                                    public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                                        if (response.isSuccessful()) {
                                            Toast.makeText(context, "Medication removed", Toast.LENGTH_SHORT).show();
                                            loadPatients();
                                        } else {
                                            Toast.makeText(context, "Failed to remove medication", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<PatientResponse> call, Throwable t) {
                                        Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                } else {
                    Toast.makeText(context, "No medications to remove", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
