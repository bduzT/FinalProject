package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;

public class Patient {

    @SerializedName("id") // Matches the JSON key returned by Flask for PatientID
    private int id; // Corresponds to PatientID in DB

    @SerializedName("firstName") // Matches the JSON key returned by Flask
    private String firstName;

    @SerializedName("lastName") // Matches the JSON key returned by Flask
    private String lastName;

    @SerializedName("dateOfBirth") // Matches the JSON key returned by Flask
    private String dateOfBirth;

    @SerializedName("gender") // Matches the JSON key returned by Flask
    private String gender;

    // Added field for photo path/URL and SerializedName annotation
    @SerializedName("Photo") // Matches the JSON key returned by Flask for the photo
    private String photo; // Assuming this field stores the path/URL

    @SerializedName("caregiverId") // Matches the JSON key returned by Flask for CaregiverID
    private int caregiverId; // Corresponds to CaregiverID in DB

    @SerializedName("faceData") // Matches the JSON key returned by Flask
    private String faceData;

    // Default constructor needed for Gson deserialization
    public Patient() {
    }

    // Constructor with fields (optional, but useful for creating objects manually)
    // Added 'photo' to the constructor
    public Patient(int id, String firstName, String lastName, String dateOfBirth, String gender, String photo, int caregiverId, String faceData) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.photo = photo; // Initialize the photo field
        this.caregiverId = caregiverId;
        this.faceData = faceData;
    }

    // --- Public Getter Methods ---

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    // Added getter method for the photo path/URL
    public String getPhoto() {
        return photo;
    }

    public int getCaregiverId() {
        return caregiverId;
    }

    public String getFaceData() {
        return faceData;
    }

    // --- Setters (Optional, if you need to modify the model after creation) ---

    public void setId(int id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    // Added setter for the photo path/URL
    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setCaregiverId(int caregiverId) {
        this.caregiverId = caregiverId;
    }

    public void setFaceData(String faceData) {
        this.faceData = faceData;
    }
    @Override
    public String toString() {
        return getFirstName() + " " + getLastName();
    }

}
