package com.khas.pillguard;

public class EditPatientActivity {
}
