package com.khas.pillguard.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.R;
import com.khas.pillguard.models.Patient;
import com.khas.pillguard.models.Caregiver;

import java.util.List;





public class AssignNurseAdapter extends RecyclerView.Adapter<AssignNurseAdapter.AssignViewHolder> {

    private List<Patient> patients;
    private List<Caregiver> nurses;
    private OnAssignListener listener;

    public interface OnAssignListener {
        void onAssign(Patient patient, Caregiver nurse);
    }

    public AssignNurseAdapter(List<Patient> patients, List<Caregiver> nurses, OnAssignListener listener) {
        this.patients = patients;
        this.nurses = nurses;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AssignViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_assign_nurse, parent, false);
        return new AssignViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AssignViewHolder holder, int position) {
        Patient patient = patients.get(position);
        holder.tvPatientName.setText(patient.getFirstName() + " " + patient.getLastName());

        ArrayAdapter<Caregiver> adapter = new ArrayAdapter<>(holder.itemView.getContext(),
                android.R.layout.simple_spinner_item, nurses);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.spinnerNurses.setAdapter(adapter);

        holder.btnAssign.setOnClickListener(v -> {
            Caregiver selectedNurse = (Caregiver) holder.spinnerNurses.getSelectedItem();
            listener.onAssign(patient, selectedNurse);
        });
    }

    @Override
    public int getItemCount() {
        return patients.size();
    }

    static class AssignViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatientName;
        Spinner spinnerNurses;
        Button btnAssign;

        public AssignViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            spinnerNurses = itemView.findViewById(R.id.spinnerNurses);
            btnAssign = itemView.findViewById(R.id.btnAssign);
        }
    }
}

