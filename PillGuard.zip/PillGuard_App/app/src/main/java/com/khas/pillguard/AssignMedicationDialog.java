package com.khas.pillguard;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.widget.*;
import androidx.annotation.NonNull;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AssignMedicationDialog extends Dialog {

    private final Context context;
    private final int patientId;
    private ListView listView;
    private ApiService apiService = ApiClient.instance;

    public AssignMedicationDialog(@NonNull Context context, int patientId) {
        super(context);
        this.context = context;
        this.patientId = patientId;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_medication_list);

        listView = findViewById(R.id.medicationListView);

        apiService.getAllMedications().enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Medication> meds = response.body();
                    ArrayAdapter<Medication> adapter = new ArrayAdapter<>(context,
                            android.R.layout.simple_list_item_1, meds);
                    listView.setAdapter(adapter);

                    listView.setOnItemClickListener((parent, view, position, id) -> {
                        Medication selectedMed = meds.get(position);
                        Intent intent = new Intent(context, AssignDetailsActivity.class);
                        intent.putExtra("medicationId", selectedMed.getId());
                        intent.putExtra("medicationName", selectedMed.getMedicationName());
                        intent.putExtra("patientId", patientId);
                        context.startActivity(intent);
                        dismiss();
                    });
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Toast.makeText(context, "Error loading medications", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
