package com.khas.pillguard;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.AddPatientRequest;
import com.khas.pillguard.models.LockSystem;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.PatientResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddPatientActivity extends AppCompatActivity {

    private static final String TAG = "AddPatientActivity";
    private static final String PREFS_NAME = "PillGuardPrefs";
    private static final String USER_ID_KEY = "userId";

    private EditText inputFirstName, inputLastName, inputID, inputDOB;
    private RadioGroup genderGroup;
    private LinearLayout medicationsContainer, medicationSection;
    private Button btnStartFaceCapture, btnSavePatient, btnAddMedication, btnToggleMedicationSection;
    private ApiService apiService;
    private String faceDataPlaceholder = "face_data_placeholder";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);

        inputFirstName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), lettersOnlyFilter});
        inputLastName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10), lettersOnlyFilter});
        inputID.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        inputDOB.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        genderGroup = findViewById(R.id.genderGroup);
        medicationsContainer = findViewById(R.id.medicationsContainer);
        medicationSection = findViewById(R.id.sectionMedicationDetails);
        btnStartFaceCapture = findViewById(R.id.btnStartFaceCapture);
        btnSavePatient = findViewById(R.id.btnSavePatient);
        btnAddMedication = findViewById(R.id.btnAddMedication);

        apiService = ApiClient.instance;

        inputFirstName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15), lettersOnlyFilter});
        inputLastName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15), lettersOnlyFilter});

        btnStartFaceCapture.setOnClickListener(v -> triggerFaceCapture());
        btnAddMedication.setOnClickListener(v -> addMedicationView());
        btnSavePatient.setOnClickListener(v -> addPatient());

        btnToggleMedicationSection.setOnClickListener(v -> {
            if (medicationSection.getVisibility() == View.GONE) {
                medicationSection.setVisibility(View.VISIBLE);
                btnToggleMedicationSection.setText("Hide Medication Section");
            } else {
                medicationSection.setVisibility(View.GONE);
                btnToggleMedicationSection.setText("Add Medication Details");
            }
        });

        addMedicationView();
    }

    private void triggerFaceCapture() {
        String patientIdStr = inputID.getText().toString().trim();
        if (patientIdStr.isEmpty()) {
            Toast.makeText(this, "Please enter patient ID first", Toast.LENGTH_SHORT).show();
            return;
        }

        int patientId = Integer.parseInt(patientIdStr);

        apiService.startFaceCapture(patientId).enqueue(new Callback<PatientResponse>() {
            @Override
            public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AddPatientActivity.this, "Face capture started", Toast.LENGTH_SHORT).show();
                    faceDataPlaceholder = "face_data_" + patientId;
                } else {
                    Toast.makeText(AddPatientActivity.this, "Failed to start face capture", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PatientResponse> call, Throwable t) {
                Toast.makeText(AddPatientActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addMedicationView() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View medicationEntryView = inflater.inflate(R.layout.item_medication_entry, null);

        Button btnRemoveMedication = medicationEntryView.findViewById(R.id.btnRemoveMedication);
        btnRemoveMedication.setOnClickListener(v -> medicationsContainer.removeView(medicationEntryView));

        medicationsContainer.addView(medicationEntryView);
    }

    private void addPatient() {
        String firstName = inputFirstName.getText().toString().trim();
        String lastName = inputLastName.getText().toString().trim();
        String patientIdStr = inputID.getText().toString().trim();
        String dateOfBirth = inputDOB.getText().toString().trim();

        String gender = "";
        int selectedGenderId = genderGroup.getCheckedRadioButtonId();
        if (selectedGenderId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedGenderId);
            gender = selectedRadioButton.getText().toString();
        }

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int caregiverId = sharedPreferences.getInt(USER_ID_KEY, -1);
        if (caregiverId == -1) {
            Toast.makeText(this, "Caregiver ID not found. Please log in again.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (firstName.isEmpty() || lastName.isEmpty() || patientIdStr.isEmpty() || dateOfBirth.isEmpty() || gender.isEmpty()) {
            Toast.makeText(this, "Please fill all patient details", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!dateOfBirth.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
            Toast.makeText(this, "DOB must be in dd/mm/yyyy format", Toast.LENGTH_SHORT).show();
            return;
        }

        int patientId;
        try {
            patientId = Integer.parseInt(patientIdStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "ID Number must be numeric", Toast.LENGTH_SHORT).show();
            return;
        }

        List<Medication> medicationsList = new ArrayList<>();
        List<LockSystem> lockSystemsList = new ArrayList<>();

        for (int i = 0; i < medicationsContainer.getChildCount(); i++) {
            View view = medicationsContainer.getChildAt(i);

            EditText inputMedicationName = view.findViewById(R.id.inputMedicationName);
            EditText inputMedicationDescription = view.findViewById(R.id.inputMedicationDescription);
            EditText inputMedicationDosage = view.findViewById(R.id.inputMedicationDosage);
            EditText inputMedicationFrequency = view.findViewById(R.id.inputMedicationFrequency);
            EditText inputMedicationTimeOfDay = view.findViewById(R.id.inputMedicationTimeOfDay);
            EditText inputMedicationStartDate = view.findViewById(R.id.inputMedicationStartDate);
            EditText inputMedicationEndDate = view.findViewById(R.id.inputMedicationEndDate);
            EditText inputLockTimeWindowStart = view.findViewById(R.id.inputLockTimeWindowStart);
            EditText inputLockTimeWindowEnd = view.findViewById(R.id.inputLockTimeWindowEnd);

            if (inputMedicationName.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Medication name required", Toast.LENGTH_SHORT).show();
                return;
            }

            Medication med = new Medication();
            med.setMedicationName(inputMedicationName.getText().toString());
            med.setDescription(inputMedicationDescription.getText().toString());
            med.setDosage(inputMedicationDosage.getText().toString());
            med.setFrequency(inputMedicationFrequency.getText().toString());
            med.setTimeOfDay(inputMedicationTimeOfDay.getText().toString());
            med.setStartDate(inputMedicationStartDate.getText().toString());
            med.setEndDate(inputMedicationEndDate.getText().toString());
            med.setStorageStatus(0);
            med.setActive(true);
            med.setLastTakenTime("");

            medicationsList.add(med);

            LockSystem lock = new LockSystem();
            lock.setTimeWindowStart(inputLockTimeWindowStart.getText().toString());
            lock.setTimeWindowEnd(inputLockTimeWindowEnd.getText().toString());
            lock.setAllowAccess(true);

            lockSystemsList.add(lock);
        }

        AddPatientRequest request = new AddPatientRequest(
                patientId, firstName, lastName, dateOfBirth, gender, caregiverId, faceDataPlaceholder, medicationsList, lockSystemsList
        );

        Gson gson = new Gson();
        String json = gson.toJson(request);
        RequestBody patientBody = RequestBody.create(MediaType.parse("application/json"), json);
        MultipartBody.Part patientPart = MultipartBody.Part.createFormData("patient_data", null, patientBody);

        apiService.addPatient(patientPart, null).enqueue(new Callback<PatientResponse>() {
            @Override
            public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AddPatientActivity.this, "Patient added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(AddPatientActivity.this, "Failed to add patient", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PatientResponse> call, Throwable t) {
                Toast.makeText(AddPatientActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private final InputFilter lettersOnlyFilter = (source, start, end, dest, dstart, dend) -> {
        Pattern pattern = Pattern.compile("[a-zA-ZğüşıöçĞÜŞİÖÇ ]+");
        if (!pattern.matcher(source).matches()) {
            return "";
        }
        return null;
    };
}
