package com.khas.pillguard.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.khas.pillguard.R;
import com.khas.pillguard.models.Medication;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AssignMedicationAdapter extends RecyclerView.Adapter<AssignMedicationAdapter.MedicationViewHolder> {

    public interface OnAssignClickListener {
        void onAssignClicked(Medication medication);
    }

    private List<Medication> medicationList;
    private Context context;
    private OnAssignClickListener listener;

    public AssignMedicationAdapter(Context context, List<Medication> medicationList, OnAssignClickListener listener) {
        this.context = context;
        this.medicationList = medicationList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_assign_medication, parent, false);
        return new MedicationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationViewHolder holder, int position) {
        Medication medication = medicationList.get(position);
        holder.tvName.setText(medication.getMedicationName());
        holder.tvDosage.setText("Dosage: " + medication.getDosage());
        holder.tvDescription.setText("Description: " + medication.getDescription());

        holder.btnAssign.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAssignClicked(medication);
            }
        });
    }

    @Override
    public int getItemCount() {
        return medicationList.size();
    }

    static class MedicationViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDosage, tvDescription;
        Button btnAssign;

        public MedicationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvMedicationName);
            tvDosage = itemView.findViewById(R.id.tvDosage);
            btnAssign = itemView.findViewById(R.id.btnAssign);
        }
    }

    public void setMedicationList(List<Medication> newList) {
        this.medicationList = newList;
        notifyDataSetChanged();
    }
}
