package com.khas.pillguard.models;

public class AdminResponse {
    private int status;
    private String message;
    private boolean success;
    private String role; // Added role field

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getRole() { // Added getRole method
        return role;
    }

    public void setRole(String role) { // Added setRole method
        this.role = role;
    }
}
