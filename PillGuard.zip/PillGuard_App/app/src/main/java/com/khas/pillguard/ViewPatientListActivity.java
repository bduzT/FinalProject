package com.khas.pillguard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Patient; // Assuming you have a Patient model
import com.khas.pillguard.adapters.PatientAdapter; // We will create this adapter

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewPatientListActivity extends AppCompatActivity {

    private static final String TAG = "ViewPatientListActivity";
    private RecyclerView recyclerViewPatients;
    private PatientAdapter patientAdapter;
    private List<Patient> patientList = new ArrayList<>();
    private ApiService apiService;

    private static final String PREFS_NAME = "PillGuardPrefs";
    private static final String USER_ID_KEY = "userId"; // Key for storing caregiver ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_patient_list); // This layout should now have recyclerViewPatients

        // Initialize RecyclerView and set its layout manager
        recyclerViewPatients = findViewById(R.id.recyclerViewPatients); // This should now resolve
        recyclerViewPatients.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the adapter with an empty list initially
        patientAdapter = new PatientAdapter(this, patientList, "admin");
        // PatientAdapter needs to be created separately
        recyclerViewPatients.setAdapter(patientAdapter);

        apiService = ApiClient.instance; // Get your Retrofit ApiService instance

        // Get the logged-in caregiver ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int caregiverId = sharedPreferences.getInt(USER_ID_KEY, -1); // Default to -1 if not found

        if (caregiverId != -1) {
            // Fetch patients for this caregiver
            loadCaregiverPatients(caregiverId);
        } else {
            // Caregiver ID not found, maybe redirect to login or show an error
            Toast.makeText(this, "Caregiver ID not found. Please log in.", Toast.LENGTH_SHORT).show();
            // Optionally, navigate back to login screen
            // Intent intent = new Intent(this, LoginActivity.class);
            // startActivity(intent);
            // finish();
        }
    }

    /**
     * Calls the API to fetch patients associated with the given caregiver ID.
     * @param caregiverId The ID of the caregiver.
     */
    private void loadCaregiverPatients(int caregiverId) {
        // Call the API endpoint to get patients by caregiver ID
        // This method should now be resolved in the updated ApiService
        Call<List<Patient>> call = apiService.getPatientsByCaregiver(caregiverId);

        call.enqueue(new Callback<List<Patient>>() {
            @Override
            public void onResponse(Call<List<Patient>> call, Response<List<Patient>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // API call successful, update the patient list
                    patientList.clear(); // Clear existing data
                    patientList.addAll(response.body()); // Add new data
                    patientAdapter.notifyDataSetChanged(); // Notify adapter to refresh the list

                    if (patientList.isEmpty()) {
                        Toast.makeText(ViewPatientListActivity.this, "No patients assigned yet.", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // Handle API error
                    String errorMessage = "Failed to load patients.";
                    if (response.errorBody() != null) {
                        try {
                            errorMessage = response.errorBody().string();
                            Log.e(TAG, "API Error Body: " + errorMessage);
                        } catch (IOException e) {
                            Log.e(TAG, "Error reading error body", e);
                        }
                    }
                    Log.e(TAG, "API Error: Code " + response.code() + ", Message: " + response.message());
                    Toast.makeText(ViewPatientListActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Patient>> call, Throwable t) {
                // Handle network errors or exceptions
                Log.e(TAG, "API Failure: " + t.getMessage(), t);
                Toast.makeText(ViewPatientListActivity.this, "Network Error: Failed to load patients.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
