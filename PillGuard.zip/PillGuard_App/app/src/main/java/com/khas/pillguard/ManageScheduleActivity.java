package com.khas.pillguard;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.khas.pillguard.adapters.PatientAdapter;
import java.util.List;
import java.util.ArrayList;
import com.khas.pillguard.models.Patient;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import android.os.Bundle;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.widget.Toast;


public class ManageScheduleActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PatientAdapter adapter;
    private List<Patient> patientList = new ArrayList<>();
    private ApiService apiService;
    private int caregiverId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_schedule);

        recyclerView = findViewById(R.id.recyclerPatientsForSchedule);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new PatientAdapter(this, patientList, "schedule");
        recyclerView.setAdapter(adapter);

        caregiverId = getSharedPreferences("PillGuardPrefs", MODE_PRIVATE)
                .getInt("userId", -1);

        apiService = ApiClient.instance;
        fetchPatients();
    }

    private void fetchPatients() {
        apiService.getPatientsByCaregiver(caregiverId).enqueue(new Callback<List<Patient>>() {
            @Override
            public void onResponse(Call<List<Patient>> call, Response<List<Patient>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    patientList.clear();
                    patientList.addAll(response.body());
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<Patient>> call, Throwable t) {
                Toast.makeText(ManageScheduleActivity.this, "Failed to load patients", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
