package com.khas.pillguard;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.view.View;



import androidx.appcompat.app.AppCompatActivity;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PatientMedicationActivity extends AppCompatActivity {

    private LinearLayout medicationContainer;
    private ApiService apiService;
    private int patientId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_medication);

        medicationContainer = findViewById(R.id.patientMedicationContainer);
        apiService = ApiClient.instance;

        loadMedications();
    }

    private void loadMedications() {
        apiService.getMedicationsByPatient(patientId).enqueue(new Callback<List<Medication>>() {
            @Override
            public void onResponse(Call<List<Medication>> call, Response<List<Medication>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Medication> medications = response.body();
                    LayoutInflater inflater = LayoutInflater.from(PatientMedicationActivity.this);

                    for (Medication med : medications) {
                        View medView = inflater.inflate(R.layout.item_patient_medication_display, medicationContainer, false);

                        TextView name = medView.findViewById(R.id.tvMedicationName);
                        TextView time = medView.findViewById(R.id.tvMedicationTime);

                        name.setText("• " + med.getMedicationName());
                        time.setText("Time: " + med.getTimeOfDay());

                        medicationContainer.addView(medView);
                    }
                } else {
                    Toast.makeText(PatientMedicationActivity.this, "No medications found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Medication>> call, Throwable t) {
                Toast.makeText(PatientMedicationActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
