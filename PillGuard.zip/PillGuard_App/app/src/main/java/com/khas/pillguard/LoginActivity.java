package com.khas.pillguard;

import com.khas.pillguard.models.LoginResponse;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.LoginRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsernameOrEmail;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvForgotPassword;

    private ApiService apiService;

    private static final String TAG = "LoginActivity";
    private static final String PREFS_NAME = "PillGuardPrefs";
    private static final String USER_ID_KEY = "userId";
    private static final String USER_TYPE_KEY = "userType";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsernameOrEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        apiService = ApiClient.instance;

        btnLogin.setOnClickListener(v -> {
            String username = etUsernameOrEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, R.string.fields_empty, Toast.LENGTH_SHORT).show();
            } else {
                performLogin(username, password);
            }
        });

        tvForgotPassword.setOnClickListener(v -> {
            String email = etUsernameOrEmail.getText().toString().trim();
            if (email.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter your email address", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, R.string.password_reset_message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void performLogin(String username, String password) {
        Log.d(TAG, "Attempting login for username: " + username);
        LoginRequest loginRequest = new LoginRequest(username, password);

        Call<LoginResponse> call = apiService.login(loginRequest);

        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();

                    if ("Login successful".equals(loginResponse.getMessage())) {
                        if (loginResponse.getAdminId() != 0) {
                            int adminId = loginResponse.getAdminId();
                            storeLoginData(adminId, "Admin");
                            navigateToAdminDashboard();
                        } else if (loginResponse.getCaregiverId() != 0) {
                            int caregiverId = loginResponse.getCaregiverId();
                            storeLoginData(caregiverId, "Caregiver");
                            navigateToCaregiverDashboard();
                        } else {
                            attemptPatientLogin(username, password);
                        }
                    } else {
                        attemptPatientLogin(username, password);
                    }
                } else {
                    attemptPatientLogin(username, password);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e(TAG, "Admin/caregiver login failed: " + t.getMessage());
                attemptPatientLogin(username, password);
            }
        });
    }

    private void attemptPatientLogin(String username, String password) {
        Call<LoginResponse> patientCall = apiService.loginPatient(new LoginRequest(username, password));

        patientCall.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null && "Giriş başarılı".equals(response.body().getMessage())) {
                    int patientId = response.body().getPatientId();
                    storeLoginData(patientId, "Patient");
                    navigateToPatientInterface(patientId);
                } else {
                    Toast.makeText(LoginActivity.this, "Giriş başarısız. Bilgileri kontrol edin.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Bağlantı hatası. Lütfen tekrar deneyin.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void storeLoginData(int userId, String userType) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(USER_ID_KEY, userId);
        editor.putString(USER_TYPE_KEY, userType);
        editor.apply();
    }

    private void navigateToAdminDashboard() {
        Intent intent = new Intent(LoginActivity.this, AdminDashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void navigateToCaregiverDashboard() {
        Intent intent = new Intent(LoginActivity.this, CaregiverDashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void navigateToPatientInterface(int patientId) {
        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
        intent.putExtra("patientId", patientId);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
