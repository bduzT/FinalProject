package com.khas.pillguard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService; // Import ApiService
import com.khas.pillguard.models.LoginRequest; // Import LoginRequest
import com.khas.pillguard.models.LoginResponse; // Import LoginResponse
// Removed ForgotPassword imports
// import com.khas.pillguard.models.ForgotPasswordRequest; // Import ForgotPasswordRequest (new model)
// import com.khas.pillguard.models.ForgotPasswordResponse; // Import ForgotPasswordResponse (new model)


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CaregiverLoginActivity extends AppCompatActivity {

    // UI elements - These IDs must match the shared activity_login.xml layout
    private EditText etUsernameOrEmail; // Assuming this is for email
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvForgotPassword; // Assuming this TextView exists

    private ApiService apiService;

    private static final String TAG = "CaregiverLogin"; // TAG for logging
    private static final String PREFS_NAME = "PillGuardPrefs"; // SharedPreferences file name
    private static final String USER_ID_KEY = "userId"; // Key for storing user ID (caregiver)
    private static final String USER_TYPE_KEY = "userType"; // Key for storing user type


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Use the shared activity_login.xml layout file

        // Check if a Caregiver user is already logged in from a previous session
        checkExistingCaregiverLogin();

        // Initialize UI components - Ensure these IDs match your activity_login.xml
        etUsernameOrEmail = findViewById(R.id.etEmail); // Assuming etEmail is used for username/email input
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvForgotPassword = findViewById(R.id.tvForgotPassword); // Assuming you have this TextView

        // Initialize ApiService using ApiClient instance
        apiService = ApiClient.instance;

        // Set click listener for the Login button
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etUsernameOrEmail.getText().toString().trim(); // Get text from the email field
                String password = etPassword.getText().toString().trim();

                // Basic validation for empty fields
                if (email.isEmpty() || password.isEmpty()) {
                    // Assuming R.string.fields_empty exists in your strings.xml
                    // Corrected reference to CaregiverLoginActivity.this
                    Toast.makeText(CaregiverLoginActivity.this, R.string.fields_empty, Toast.LENGTH_SHORT).show();
                } else {
                    // Attempt to perform login via the single API endpoint
                    performLogin(email, password); // Call the generic performLogin
                }
            }
        });

        // Set click listener for the Forgot Password TextView
        if (tvForgotPassword != null) {
            tvForgotPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = etUsernameOrEmail.getText().toString().trim(); // Get email from the input field
                    if (email.isEmpty()) {
                        // Corrected reference to CaregiverLoginActivity.this
                        Toast.makeText(CaregiverLoginActivity.this, "Please enter your email address to reset password", Toast.LENGTH_SHORT).show();
                    } else {
                        // TODO: Implement actual password reset logic (e.g., API call to /forgot_password)
                        // For now, just show a message based on R.string.password_reset_message
                        // Corrected reference to CaregiverLoginActivity.this
                        Toast.makeText(CaregiverLoginActivity.this, R.string.password_reset_message, Toast.LENGTH_LONG).show();
                        // If you re-implement the API call, you'll need the ForgotPasswordRequest/Response models and the requestPasswordReset method back.
                        // requestPasswordReset(email);
                    }
                }
            });
        }
    }

    /**
     * Checks SharedPreferences to see if a Caregiver user is already logged in.
     * If a valid session is found, navigates directly to the User List activity.
     */
    private void checkExistingCaregiverLogin() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String userType = sharedPreferences.getString(USER_TYPE_KEY, null);

        // Check if a user type is stored and if it's "Caregiver"
        if (userType != null && userType.equals("Caregiver")) {
            int caregiverId = sharedPreferences.getInt(USER_ID_KEY, -1); // Use USER_ID_KEY
            // Check if a valid caregiver ID is stored
            if (caregiverId != -1) {
                Log.d(TAG, "Caregiver ID found in SharedPreferences: " + caregiverId + ". Navigating to User List.");
                // Navigate to the main caregiver screen (UserListActivity)
                navigateToUserList();
            }
        }
        // If no existing Caregiver login is found, the activity remains visible for login
    }


    /**
     * Performs the login API call using the single /login endpoint.
     *
     * @param username The username/email entered by the user.
     * @param password The password entered by the user.
     */
    private void performLogin(String username, String password) {
        Log.d(TAG, "Attempting login for username: " + username);

        // Create a LoginRequest object with the credentials
        LoginRequest loginRequest = new LoginRequest(username, password);

        // Call the single login method from the ApiService interface
        Call<LoginResponse> call = apiService.login(loginRequest); // *** CORRECTED API CALL ***

        // Enqueue the API call for asynchronous execution
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                // Check if the API response was successful (HTTP status code 2xx)
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();
                    // Check the message returned in the response body from the Flask API
                    if (loginResponse.getMessage() != null && loginResponse.getMessage().equals("Login successful")) {
                        // Login was successful. Now check if it was a Caregiver login.
                        // Assuming LoginResponse has getCaregiverId() and it's non-zero for caregivers
                        int caregiverId = loginResponse.getCaregiverId();

                        if (caregiverId != 0) { // Check if a caregiver ID was returned
                            // This is a successful Caregiver login
                            // Store the caregiver ID and user type in SharedPreferences for session management
                            SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt(USER_ID_KEY, caregiverId); // Store caregiver ID
                            editor.putString(USER_TYPE_KEY, "Caregiver"); // Store user type
                            editor.apply(); // Use apply() for asynchronous save

                            Log.i(TAG, "Caregiver login successful. ID: " + caregiverId);
                            // Corrected reference to CaregiverLoginActivity.this
                            Toast.makeText(CaregiverLoginActivity.this, "Caregiver Login successful", Toast.LENGTH_SHORT).show();

                            // Navigate to the main activity for caregivers (UserListActivity)
                            navigateToUserList();

                        } else {
                            // Login successful message received, but it wasn't a Caregiver login
                            // This might happen if admin credentials were used on this screen
                            Log.w(TAG, "Login successful, but not a Caregiver login.");
                            // Corrected reference to CaregiverLoginActivity.this
                            Toast.makeText(CaregiverLoginActivity.this, "Login successful, but not a Caregiver account.", Toast.LENGTH_SHORT).show();
                            // You might want to handle this case, perhaps showing a message or redirecting
                        }

                    } else {
                        // Login failed according to the server response message
                        Log.w(TAG, "Login failed: " + loginResponse.getMessage());
                        Toast.makeText(CaregiverLoginActivity.this, "Login failed: Invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // API call was not successful (e.g., HTTP status code 401 Unauthorized, 404 Not Found, 500 Internal Server Error)
                    Log.e(TAG, "Login API call failed: " + response.code() + " - " + response.message());
                    Toast.makeText(CaregiverLoginActivity.this, "Login failed. Please check credentials.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                // Network error or exception occurred during the API call
                Log.e(TAG, "Login network error: " + t.getMessage(), t);
                Toast.makeText(CaregiverLoginActivity.this, "Network error during login", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Sends a request to the API to initiate the password reset process for a caregiver.
     * (This method is commented out as the API call is not fully implemented in this context)
     *
     * @param email The email address for which to reset the password.
     */
    // private void requestPasswordReset(String email) {
    //     Log.d(TAG, "Requesting password reset for email: " + email);
    //
    //     // Create a ForgotPasswordRequest object with the email
    //     ForgotPasswordRequest forgotPasswordRequest = new ForgotPasswordRequest(email); // Assuming ForgotPasswordRequest constructor takes email
    //
    //     // Call the forgotPassword method from the ApiService interface
    //     Call<ForgotPasswordResponse> call = apiService.forgotPassword(forgotPasswordRequest); // Assuming forgotPassword() returns Call<ForgotPasswordResponse>
    //
    //     call.enqueue(new Callback<ForgotPasswordResponse>() {
    //         @Override
    //         public void onResponse(Call<ForgotPasswordResponse> call, Response<ForgotPasswordResponse> response) {
    //             if (response.isSuccessful() && response.body() != null) {
    //                 ForgotPasswordResponse forgotPasswordResponse = response.body();
    //                 Log.d(TAG, "Forgot password response: " + forgotPasswordResponse.getMessage());
    //                 // Show the message received from the API (e.g., "Password reset instructions sent")
    //                 Toast.makeText(CaregiverLoginActivity.this, forgotPasswordResponse.getMessage(), Toast.LENGTH_SHORT).show();
    //                 // TODO: Optionally navigate to a confirmation screen or stay on login
    //             } else {
    //                 Log.e(TAG, "Forgot password API call failed: " + response.code() + " - " + response.message());
    //                 Toast.makeText(CaregiverLoginActivity.this, "Failed to request password reset. Please check email.", Toast.LENGTH_SHORT).show();
    //             }
    //         }
    //
    //         @Override
    //         public void onFailure(Call<ForgotPasswordResponse> call, Throwable t) {
    //             Log.e(TAG, "Forgot password network error: " + t.getMessage(), t);
    //             Toast.makeText(CaregiverLoginActivity.this, "Network error requesting password reset", Toast.LENGTH_SHORT).show();
    //         }
    //     });
    // }


    /**
     * Navigates to the UserListActivity and clears the activity stack.
     */
    private void navigateToUserList() {
        Intent intent = new Intent(CaregiverLoginActivity.this, UserListActivity.class); // Make sure UserListActivity exists
        // Flags to clear the activity stack so the user cannot go back to the login screen with the back button
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish(); // Close the CaregiverLoginActivity
    }

    // You might want to add a method to navigate to the Admin Login Activity if needed
    // For example, if you have a button/link on the login screen to switch roles.
}
