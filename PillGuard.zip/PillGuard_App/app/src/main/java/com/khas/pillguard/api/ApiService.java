package com.khas.pillguard.api;

import com.khas.pillguard.models.*;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    // --- CAREGIVER ---
    @Multipart
    @POST("/caregiver")
    Call<CaregiverResponse> addCaregiver(
            @Part("first_name") RequestBody firstName,
            @Part("last_name") RequestBody lastName,
            @Part("contact_info") RequestBody contactInfo,
            @Part("dob") RequestBody dob,
            @Part MultipartBody.Part photo,
            @Part("admin_id") RequestBody adminId,
            @Part("username") RequestBody username,
            @Part("password") RequestBody password
    );

    @GET("/caregivers")
    Call<List<Caregiver>> getCaregivers();

    @GET("/caregiver/{id}")
    Call<Caregiver> getCaregiverById(@Path("id") int id);

    @Multipart
    @PUT("/caregiver/{id}")
    Call<CaregiverResponse> updateCaregiver(
            @Path("id") int id,
            @Part("first_name") RequestBody firstName,
            @Part("last_name") RequestBody lastName,
            @Part("contact_info") RequestBody contactInfo,
            @Part("dob") RequestBody dob,
            @Part MultipartBody.Part photo,
            @Part("username") RequestBody username,
            @Part("password") RequestBody password
    );

    @DELETE("/caregiver/{id}")
    Call<CaregiverResponse> deleteCaregiver(@Path("id") int id);


    // --- PATIENT ---
    @Multipart
    @POST("/patient")
    Call<PatientResponse> addPatient(
            @Part MultipartBody.Part patientDataJsonPart,
            @Part MultipartBody.Part photo
    );

    @GET("/patients")
    Call<List<Patient>> getPatients();

    @GET("/patient/{id}")
    Call<Patient> getPatientById(@Path("id") int id);

    @Multipart
    @PUT("/patient/{id}")
    Call<Patient> updatePatient(
            @Path("id") int id,
            @Part("first_name") RequestBody firstName,
            @Part("last_name") RequestBody lastName,
            @Part("dob") RequestBody dob,
            @Part("gender") RequestBody gender,
            @Part MultipartBody.Part photo,
            @Part("caregiver_id") RequestBody caregiverId,
            @Part("face_data") RequestBody faceData
    );

    @DELETE("/patient/{id}")
    Call<PatientResponse> deletePatient(@Path("id") int id);


    // --- MEDICATION ---
    @GET("/medications")
    Call<List<Medication>> getAllMedications();

    @GET("/patient/{patient_id}/medications")
    Call<List<Medication>> getMedicationsByPatient(@Path("patient_id") int patientId);

    @POST("/medication")
    Call<PatientResponse> addMedication(@Body Medication medication);

    @DELETE("/medication/{id}")
    Call<PatientResponse> deleteMedication(@Path("id") int medicationId);

    @PUT("/pill-schedule/medication/{medication_id}")
    Call<PatientResponse> updateMedication(@Path("medication_id") int medicationId, @Body Medication medication);


    // --- AUTH ---
    @POST("/login")
    Call<LoginResponse> login(@Body LoginRequest loginRequest);

    @POST("/login/patient")
    Call<LoginResponse> loginPatient(@Body LoginRequest request);


    // --- ASSIGNMENTS ---
    @POST("/assign-nurse")
    Call<Void> assignNurseToPatient(
            @Query("patientId") int patientId,
            @Query("caregiverId") int caregiverId
    );

    @GET("/assignments")
    Call<List<Assignment>> getAssignments();

    @DELETE("/assignment/{assignmentId}")
    Call<Void> deleteAssignment(@Path("assignmentId") int assignmentId);


    // --- EXTRA ---
    @POST("/forgot_password")
    Call<ForgotPasswordResponse> forgotPassword(@Body ForgotPasswordRequest forgotPasswordRequest);

    @POST("/start-face-capture")
    Call<PatientResponse> startFaceCapture(@Query("patient_id") int patientId);

    @GET("/caregiver/{caregiver_id}/patients")
    Call<List<Patient>> getPatientsByCaregiver(@Path("caregiver_id") int caregiverId);

    @POST("/unlock-box")
    Call<PatientResponse> unlockBox(@Query("patient_id") int patientId);

    @POST("/global-medication")
    Call<PatientResponse> addGlobalMedication(@Body Medication medication);

    @DELETE("/global-medication/{id}")
    Call<PatientResponse> deleteGlobalMedication(@Path("id") int medicationId);

    @PUT("/global-medication/{id}")
    Call<PatientResponse> updateGlobalMedication(@Path("id") int medicationId, @Body Medication medication);

    @POST("/patient/{patient_id}/medication")
    Call<PatientResponse> assignMedicationToPatient(
            @Path("patient_id") int patientId,
            @Body Medication medication
    );

}
