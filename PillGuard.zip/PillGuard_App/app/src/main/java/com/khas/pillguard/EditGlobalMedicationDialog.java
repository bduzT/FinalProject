package com.khas.pillguard;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.khas.pillguard.R;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.PatientResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditGlobalMedicationDialog extends Dialog {

    private EditText etMedicationName, etDescription, etDosage;
    private Button btnSave, btnCancel;
    private final Medication medication;
    private final OnMedicationUpdatedListener listener;
    private final ApiService apiService;

    public interface OnMedicationUpdatedListener {
        void onMedicationUpdated(Medication updatedMedication);
    }

    public EditGlobalMedicationDialog(@NonNull Context context, Medication medication, OnMedicationUpdatedListener listener) {
        super(context);
        this.medication = medication;
        this.listener = listener;
        this.apiService = ApiClient.instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_add_medication);

        etMedicationName = findViewById(R.id.etMedicationName);
        etDescription = findViewById(R.id.etDescription);
        etDosage = findViewById(R.id.etDosage);
        btnSave = findViewById(R.id.btnSaveMedication);
        btnCancel = findViewById(R.id.btnCancelMedication);

        etMedicationName.setText(medication.getMedicationName());
        etDescription.setText(medication.getDescription());
        etDosage.setText(medication.getDosage());

        btnSave.setOnClickListener(v -> {
            String name = etMedicationName.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String dosage = etDosage.getText().toString().trim();

            if (name.isEmpty() || dosage.isEmpty()) {
                Toast.makeText(getContext(), "Please fill in required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            medication.setMedicationName(name);
            medication.setDescription(description);
            medication.setDosage(dosage);

            // Backend'in zorunlu alanlarını garanti altına al
            if (medication.getQrCode() == null) medication.setQrCode("");
            if (medication.getFrequency() == null) medication.setFrequency("");
            medication.setActive(true);

            // 💥 BURADA ID'Yİ KONTROL EDİYORUZ
            Log.d("MED_UPDATE", "Updating ID: " + medication.getId());

            Call<PatientResponse> call = apiService.updateGlobalMedication(medication.getId(), medication);
            call.enqueue(new Callback<PatientResponse>() {
                @Override
                public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(getContext(), "Medication updated", Toast.LENGTH_SHORT).show();
                        if (listener != null) {
                            listener.onMedicationUpdated(medication);
                        }
                        dismiss();
                    } else {
                        Toast.makeText(getContext(), "Update failed: " + response.code(), Toast.LENGTH_SHORT).show();
                        Log.e("MED_UPDATE", "FAILED with code " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<PatientResponse> call, Throwable t) {
                    Toast.makeText(getContext(), "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("MED_UPDATE", "ERROR: " + t.getMessage());
                }
            });
        });

        btnCancel.setOnClickListener(v -> dismiss());
    }
}
