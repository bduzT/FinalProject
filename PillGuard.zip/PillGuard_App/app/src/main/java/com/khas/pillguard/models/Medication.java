package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;

public class Medication {

    @SerializedName("patient_id")
    private int patientId;

    @SerializedName("caregiver_id")
    private int caregiverId;

    @SerializedName("medication_name")
    private String medicationName;

    @SerializedName("description")
    private String description;

    @SerializedName("qr_code")
    private String qrCode;

    @SerializedName("dosage")
    private String dosage;

    @SerializedName("frequency")
    private String frequency;

    @SerializedName("time_of_day")
    private String timeOfDay;

    @SerializedName("start_date")
    private String startDate;

    @SerializedName("end_date")
    private String endDate;

    @SerializedName("storage_status")
    private int storageStatus;

    @SerializedName("last_taken_time")
    private String lastTakenTime;

    @SerializedName("is_active")
    private boolean isActive;

    @SerializedName("medication_id")
    private int medicationId;

    @SerializedName("id")
    private int id;

    @Override
    public String toString() {
        return medicationName;
    }



    public Medication() {}


    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public int getCaregiverId() { return caregiverId; }
    public void setCaregiverId(int caregiverId) { this.caregiverId = caregiverId; }

    public String getMedicationName() { return medicationName; }
    public void setMedicationName(String medicationName) { this.medicationName = medicationName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }

    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public String getTimeOfDay() { return timeOfDay; }
    public void setTimeOfDay(String timeOfDay) { this.timeOfDay = timeOfDay; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public int getStorageStatus() { return storageStatus; }
    public void setStorageStatus(int storageStatus) { this.storageStatus = storageStatus; }

    public String getLastTakenTime() { return lastTakenTime; }
    public void setLastTakenTime(String lastTakenTime) { this.lastTakenTime = lastTakenTime; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public int getMedicationId() { return medicationId; }
    public void setMedicationId(int medicationId) { this.medicationId = medicationId; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}
