package com.khas.pillguard.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class MedicationResponse {

    @SerializedName("medications")
    private List<Medication> medications;

    public List<Medication> getMedications() {
        return medications;
    }

    public void setMedications(List<Medication> medications) {
        this.medications = medications;
    }
}
