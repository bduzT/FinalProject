package com.khas.pillguard.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.khas.pillguard.R;
import com.khas.pillguard.models.UserModel;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private List<UserModel> userList;
    private OnUserActionListener listener;

    public interface OnUserActionListener {
        void onDeleteClick(int userId, String userType);
        void onViewDetailsClick(int userId, String userType);
        void onEditClick(int userId, String userType);
    }

    public UserAdapter(List<UserModel> users, OnUserActionListener listener) {
        this.userList = users;
        this.listener = listener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        UserModel user = userList.get(position);

        holder.tvUserName.setText(user.getFirstName() + " " + user.getLastName());
        holder.tvUserDetails.setText("Type: " + user.getUserType());

        String photoPath = user.getPhotoPath();

        Glide.with(holder.itemView.getContext())
                .load(photoPath)
                .placeholder(R.drawable.default_user_icon)
                .error(R.drawable.default_user_icon) // işte burası düzeldi
                .into(holder.ivUserPhoto);

        // Edit butonu görünürlük:
        if (user.getUserType().equalsIgnoreCase("Patient")) {
            holder.ivEditUser.setVisibility(View.GONE);
        } else {
            holder.ivEditUser.setVisibility(View.VISIBLE);
        }

        if (listener != null) {
            holder.itemView.setOnClickListener(v -> listener.onViewDetailsClick(user.getAssociatedId(), user.getUserType()));
            holder.ivDeleteUser.setOnClickListener(v -> listener.onDeleteClick(user.getAssociatedId(), user.getUserType()));
            holder.ivEditUser.setOnClickListener(v -> listener.onEditClick(user.getAssociatedId(), user.getUserType()));
        }
    }


    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserName, tvUserDetails;
        ImageView ivUserPhoto, ivEditUser, ivDeleteUser;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvUserDetails = itemView.findViewById(R.id.tvUserDetails);
            ivUserPhoto = itemView.findViewById(R.id.ivUserPhoto);
            ivEditUser = itemView.findViewById(R.id.ivEditUser);
            ivDeleteUser = itemView.findViewById(R.id.ivDeleteUser);
        }
    }

    public void setUserList(List<UserModel> newUserList) {
        this.userList = newUserList;
        notifyDataSetChanged();
    }
}
