package com.khas.pillguard.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.R;
import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.PatientResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MedicationAssignmentAdapter extends RecyclerView.Adapter<MedicationAssignmentAdapter.MedicationViewHolder> {

    private final Context context;
    private final List<Medication> medications;
    private final int patientId;
    private final ApiService apiService = ApiClient.instance;

    public MedicationAssignmentAdapter(Context context, List<Medication> medications, int patientId) {
        this.context = context;
        this.medications = medications;
        this.patientId = patientId;
    }

    @NonNull
    @Override
    public MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_assign_medication, parent, false);
        return new MedicationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationViewHolder holder, int position) {
        Medication med = medications.get(position);
        holder.tvName.setText(med.getMedicationName());

        holder.btnAssign.setOnClickListener(v -> {
            String freq = holder.etFrequency.getText().toString().trim();
            String time = holder.etTimeRange.getText().toString().trim();

            if (freq.isEmpty() || time.isEmpty()) {
                Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Medication assignment = new Medication();
            assignment.setPatientId(patientId);
            assignment.setCaregiverId(2); // örnek caregiver ID
            assignment.setMedicationId(med.getId());
            assignment.setTimeOfDay(time);
            assignment.setFrequency(freq);
            assignment.setStartDate("2025-01-01");
            assignment.setEndDate("2025-12-31");
            assignment.setStorageStatus(0);
            assignment.setLastTakenTime("2025-01-01");
            assignment.setActive(true);

            apiService.assignMedicationToPatient(patientId, assignment).enqueue(new Callback<PatientResponse>() {
                @Override
                public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(context, "Assigned successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Assignment failed", Toast.LENGTH_SHORT).show();
                        try {
                            if (response.errorBody() != null) {
                                String errorBody = response.errorBody().string();
                                android.util.Log.e("ASSIGN_ERROR_BODY", errorBody);
                            }
                        } catch (Exception e) {
                            android.util.Log.e("ASSIGN_ERROR", "Error reading error body", e);
                        }
                    }
                }

                @Override
                public void onFailure(Call<PatientResponse> call, Throwable t) {
                    Toast.makeText(context, "Server error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    android.util.Log.e("ASSIGN_FAILURE", t.getMessage(), t);
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return medications.size();
    }

    static class MedicationViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        EditText etFrequency, etTimeRange;
        Button btnAssign;

        public MedicationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvMedicationName);
            etFrequency = itemView.findViewById(R.id.etFrequency);
            etTimeRange = itemView.findViewById(R.id.etTimeRange);
            btnAssign = itemView.findViewById(R.id.btnAssign);
        }
    }
}
