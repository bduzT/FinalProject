package com.khas.pillguard;

import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.khas.pillguard.api.ApiClient;
import com.khas.pillguard.api.ApiService;
import com.khas.pillguard.models.Medication;
import com.khas.pillguard.models.PatientResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AssignDetailsActivity extends AppCompatActivity {

    private TextView tvMedName;
    private EditText etFrequency, etTimeRange;
    private Button btnAssign;

    private int patientId;
    private int medicationId;
    private String medicationName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_details);

        tvMedName = findViewById(R.id.tvMedName);
        etFrequency = findViewById(R.id.etFrequency);
        etTimeRange = findViewById(R.id.etTimeRange);
        btnAssign = findViewById(R.id.btnAssignNow);

        // Get values from intent
        patientId = getIntent().getIntExtra("patientId", -1);
        medicationId = getIntent().getIntExtra("medicationId", -1);
        medicationName = getIntent().getStringExtra("medicationName");

        tvMedName.setText(medicationName);

        btnAssign.setOnClickListener(v -> {
            String freq = etFrequency.getText().toString().trim();
            String time = etTimeRange.getText().toString().trim();

            if (freq.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Medication assignment = new Medication();
            assignment.setPatientId(patientId);
            assignment.setCaregiverId(2); // örnek caregiver ID
            assignment.setMedicationId(medicationId);
            assignment.setTimeOfDay(time);
            assignment.setFrequency(freq);
            assignment.setStartDate("2025-01-01");
            assignment.setEndDate("2025-12-31");
            assignment.setStorageStatus(0);
            assignment.setLastTakenTime("2025-01-01");
            assignment.setActive(true);

            ApiService api = ApiClient.instance;
            api.assignMedicationToPatient(patientId, assignment).enqueue(new Callback<PatientResponse>() {
                @Override
                public void onResponse(Call<PatientResponse> call, Response<PatientResponse> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(AssignDetailsActivity.this, "Assigned successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AssignDetailsActivity.this, "Assignment failed", Toast.LENGTH_SHORT).show();
                        Log.e("ASSIGN_ERROR", "Code: " + response.code() + " - " + response.message());
                        try {
                            if (response.errorBody() != null) {
                                Log.e("ASSIGN_ERROR_BODY", response.errorBody().string());
                            }
                        } catch (Exception e) {
                            Log.e("ASSIGN_ERROR_BODY", "Exception reading error body", e);
                        }
                    }
                }

                @Override
                public void onFailure(Call<PatientResponse> call, Throwable t) {
                    Toast.makeText(AssignDetailsActivity.this, "Server error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("ASSIGN_FAILURE", t.getMessage(), t);
                }
            });
        });
    }
}
