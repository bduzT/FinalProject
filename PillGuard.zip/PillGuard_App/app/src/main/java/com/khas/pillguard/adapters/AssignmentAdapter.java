package com.khas.pillguard.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.khas.pillguard.R;
import com.khas.pillguard.models.Assignment;

import java.util.List;

public class AssignmentAdapter extends RecyclerView.Adapter<AssignmentAdapter.AssignmentViewHolder> {

    public interface OnAssignmentActionListener {
        void onDeleteAssignment(int assignmentId);
    }

    private List<Assignment> assignmentList;
    private OnAssignmentActionListener listener;

    public AssignmentAdapter(List<Assignment> assignmentList, OnAssignmentActionListener listener) {
        this.assignmentList = assignmentList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AssignmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_assignment, parent, false);
        return new AssignmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AssignmentViewHolder holder, int position) {
        Assignment assignment = assignmentList.get(position);

        holder.tvPatientName.setText("Patient: " + assignment.getPatientName());
        holder.tvCaregiverName.setText("Nurse: " + assignment.getCaregiverName());

        holder.btnDeleteAssignment.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteAssignment(assignment.getAssignmentId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return assignmentList.size();
    }

    static class AssignmentViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatientName, tvCaregiverName;
        Button btnDeleteAssignment;

        public AssignmentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            tvCaregiverName = itemView.findViewById(R.id.tvCaregiverName);
            btnDeleteAssignment = itemView.findViewById(R.id.btnDeleteAssignment);
        }
    }
}
