# PillGuard_App
 Android app for PillGuard
###########
User Roles & Access

3 types of users:

#Patient
- View own pill schedule
- Receive notifications
- View intake history
- NFC 

#Nurse
- Manage pill schedules for assigned patients
- Remote unlock pillboxes
- Monitor intake history

#Admin
- Add/remove users (patients/nurses)
- Assign nurses to patients
- Full access to schedules and logs

